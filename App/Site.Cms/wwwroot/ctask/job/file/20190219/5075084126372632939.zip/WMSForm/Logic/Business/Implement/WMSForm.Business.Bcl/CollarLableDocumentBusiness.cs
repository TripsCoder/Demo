using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Util;
using MicBeach.Develop.UnitOfWork;
using MicBeach.Util.Response;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Service;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.BusinessContract.Bcl;
using WMSForm.Domain.Bcl.Service.Request;

namespace WMSForm.Business.Bcl
{
    /// <summary>
    /// 领标单业务
    /// </summary>
    public class CollarLableDocumentBusiness:ICollarLableDocumentBusiness
    {
        public CollarLableDocumentBusiness()
        {
        }

        #region 保存领标单

        /// <summary>
        /// 保存领标单
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentDto> SaveCollarLableDocument(SaveCollarLableDocumentCmdDto saveInfo)
		{
            if (saveInfo == null)
            {
                return Result<CollarLableDocumentDto>.FailedResult("没有指定任何要保持的信息");
            }
            using (var businessWork = UnitOfWork.Create())
            {
                var saveResult = CollarLableDocumentService.SaveCollarLableDocument(saveInfo.CollarLableDocument.MapTo<CollarLableDocument>());
                if (!saveResult.Success)
                {
                    return Result<CollarLableDocumentDto>.FailedResult(saveResult.Message);
                }
                var commitResult = businessWork.Commit();
                Result<CollarLableDocumentDto> result = null;
                if (commitResult.ExecutedSuccess)
                {
                    result = Result<CollarLableDocumentDto>.SuccessResult("保存成功");
                    result.Data = saveResult.Data.MapTo<CollarLableDocumentDto>();
                }
                else
                {
                    result = Result<CollarLableDocumentDto>.FailedResult("保存失败");
                }
                return result;
            }
		}

        #endregion

        #region 获取领标单

        /// <summary>
        /// 获取领标单
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentDto GetCollarLableDocument(CollarLableDocumentFilterDto filter)
		{
            var collarLableDocument = CollarLableDocumentService.GetCollarLableDocument(CreateQueryObject(filter));
            return collarLableDocument.MapTo<CollarLableDocumentDto>();
		}

        #endregion

        #region 获取领标单列表

        /// <summary>
        /// 获取领标单列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentDto> GetCollarLableDocumentList(CollarLableDocumentFilterDto filter)
		{
			var collarLableDocumentList = CollarLableDocumentService.GetCollarLableDocumentList(CreateQueryObject(filter));
            return collarLableDocumentList.Select(c => c.MapTo<CollarLableDocumentDto>()).ToList();
		}

        #endregion

		#region 获取领标单分页

        /// <summary>
        /// 获取领标单分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentDto> GetCollarLableDocumentPaging(CollarLableDocumentFilterDto filter)
		{
		    var collarLableDocumentPaging = CollarLableDocumentService.GetCollarLableDocumentPaging(CreateQueryObject(filter));
            return collarLableDocumentPaging.ConvertTo<CollarLableDocumentDto>();
		}

        #endregion

		#region 删除领标单

        /// <summary>
        /// 删除领标单
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocument(DeleteCollarLableDocumentCmdDto deleteInfo)
        {
            #region 参数判断

            if (deleteInfo == null || deleteInfo.CollarLableDocumentIds.IsNullOrEmpty())
            {
                return Result.FailedResult("没有指定要删除的领标单");
            }

            #endregion

            using (var businessWork = UnitOfWork.Create())
            {
                var deleteResult = CollarLableDocumentService.DeleteCollarLableDocument(deleteInfo.MapTo<DeleteCollarLableDocument>());
                if (!deleteResult.Success)
                {
                    return deleteResult;
                }
                var commitResult = businessWork.Commit();
                return commitResult.ExecutedSuccess ? Result.SuccessResult("删除成功") : Result.FailedResult("删除失败");
            }
        }

        #endregion

		#region 根据查询条件生成查询对象

        /// <summary>
        /// 根据查询条件生成查询对象
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IQuery CreateQueryObject(CollarLableDocumentFilterDto filter)
        {
            if (filter == null)
            {
                return null;
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentQuery>(filter);

			#region 数据筛选

							if(!filter.SysNos.IsNullOrEmpty())
			{
				query.In<CollarLableDocumentQuery>(c => c.SysNo, filter.SysNos);
			}
            if (!filter.ExcludeSysNos.IsNullOrEmpty())
            {
                query.NotIn<CollarLableDocumentQuery>(c => c.SysNo, filter.ExcludeSysNos);
            }
										if(!filter.BillNo.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BillNo, filter.BillNo);
			}
										if(!filter.BillTitle.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BillTitle, filter.BillTitle);
			}
										if(filter.BillType.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.BillType, filter.BillType.Value);
			}
							            if(!filter.UserSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.UserSysNo, filter.UserSysNo);
			}
            							if(!filter.UserName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.UserName, filter.UserName);
			}
										if(!filter.EnterpriseName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.EnterpriseName, filter.EnterpriseName);
			}
										if(!filter.EnterpriseCode.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.EnterpriseCode, filter.EnterpriseCode);
			}
							            if(!filter.DepartmentSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.DepartmentSysNo, filter.DepartmentSysNo);
			}
            							if(!filter.DepartmentName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.DepartmentName, filter.DepartmentName);
			}
										if(filter.InvoiceType.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.InvoiceType, filter.InvoiceType.Value);
			}
										if(!filter.Remark.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.Remark, filter.Remark);
			}
										if(filter.BillStatus.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.BillStatus, filter.BillStatus.Value);
			}
										if(filter.LastUpdateDate.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.LastUpdateDate, filter.LastUpdateDate.Value);
			}
										if(filter.SubmitDate.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.SubmitDate, filter.SubmitDate.Value);
			}
										if(filter.TotalAdjuvantAmount.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.TotalAdjuvantAmount, filter.TotalAdjuvantAmount.Value);
			}
										if(filter.TotalServiceAmount.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.TotalServiceAmount, filter.TotalServiceAmount.Value);
			}
										if(filter.PaidAdjuvantAmount.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.PaidAdjuvantAmount, filter.PaidAdjuvantAmount.Value);
			}
										if(filter.PaidServiceAmount.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.PaidServiceAmount, filter.PaidServiceAmount.Value);
			}
										if(filter.PaidAmount.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.PaidAmount, filter.PaidAmount.Value);
			}
										if(!filter.LogisticsName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.LogisticsName, filter.LogisticsName);
			}
										if(!filter.LogisticsNo.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.LogisticsNo, filter.LogisticsNo);
			}
							            if(!filter.BrandSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BrandSysNo, filter.BrandSysNo);
			}
            							if(!filter.BrandName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BrandName, filter.BrandName);
			}
										if(!filter.BrandEnterpriseName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BrandEnterpriseName, filter.BrandEnterpriseName);
			}
										if(!filter.BillDescRemark.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.BillDescRemark, filter.BillDescRemark);
			}
										if(filter.IsGenerateLableCode.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.IsGenerateLableCode, filter.IsGenerateLableCode.Value);
			}
							            if(!filter.StoreSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.StoreSysNo, filter.StoreSysNo);
			}
            							if(!filter.StoreName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentQuery>(c => c.StoreName, filter.StoreName);
			}
										if(filter.ApplyYearService.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.ApplyYearService, filter.ApplyYearService.Value);
			}
										if(filter.VersionNo.HasValue)
			{
            query.Equal<CollarLableDocumentQuery>(c => c.VersionNo, filter.VersionNo.Value);
			}
					
			#endregion

            #region 数据加载


            #endregion

            return query;
        }

        #endregion
    }
}
