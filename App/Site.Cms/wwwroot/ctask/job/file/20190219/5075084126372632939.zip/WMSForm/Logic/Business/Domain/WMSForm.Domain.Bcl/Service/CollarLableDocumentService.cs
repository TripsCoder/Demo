using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using MicBeach.Util;
using MicBeach.Util.IoC;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Service.Request;

namespace WMSForm.Domain.Bcl.Service
{
    /// <summary>
    /// 领标单服务
    /// </summary>
    public static class CollarLableDocumentService
    {
        static ICollarLableDocumentRepository collarLableDocumentRepository = ContainerManager.Container.Resolve<ICollarLableDocumentRepository>();

        #region 保存

        /// <summary>
        /// 保存领标单
        /// </summary>
        /// <param name="collarLableDocument">领标单信息</param>
        /// <returns></returns>
        public static Result<CollarLableDocument> SaveCollarLableDocument(CollarLableDocument collarLableDocument)
        {
            if (collarLableDocument == null)
            {
                return Result<CollarLableDocument>.FailedResult("领标单信息为空");
            }
            if (collarLableDocument.PrimaryValueIsNone())
            {
                return AddCollarLableDocument(collarLableDocument);
            }
            else
            {
                return EditCollarLableDocument(collarLableDocument);
            }
        }

        /// <summary>
        /// 添加领标单
        /// </summary>
        /// <param name="collarLableDocument">领标单对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocument> AddCollarLableDocument(CollarLableDocument collarLableDocument)
        {
            #region 参数判断

            if (collarLableDocument == null)
            {
                return Result<CollarLableDocument>.FailedResult("没有指定要添加的领标单数据");
            }

            #endregion

            collarLableDocument.Save();
            var result = Result<CollarLableDocument>.SuccessResult("添加成功");
            result.Data = collarLableDocument;
            return result;
        }

        /// <summary>
        /// 编辑领标单
        /// </summary>
        /// <param name="newCollarLableDocument">领标单对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocument> EditCollarLableDocument(CollarLableDocument newCollarLableDocument)
        {
            #region 参数判断

            if (newCollarLableDocument == null)
            {
                return Result<CollarLableDocument>.FailedResult("没有指定要操作的领标单信息");
            }

            #endregion

            CollarLableDocument collarLableDocument = collarLableDocumentRepository.Get(QueryFactory.Create<CollarLableDocumentQuery>(r => r.SysNo == newCollarLableDocument.SysNo));
            if (collarLableDocument == null)
            {
                return Result<CollarLableDocument>.FailedResult("没有指定要操作的领标单信息");
            }

            //修改信息
            collarLableDocument.LastUpdateDate = newCollarLableDocument.LastUpdateDate;
            collarLableDocument.Save();
            var result = Result<CollarLableDocument>.SuccessResult("修改成功");
            result.Data = collarLableDocument;
            return result;
        }

        #endregion

        #region 获取领标单

        /// <summary>
        /// 获取领标单
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static CollarLableDocument GetCollarLableDocument(IQuery query)
        {
            var collarLableDocument = collarLableDocumentRepository.Get(query);
            return collarLableDocument;
        }

        /// <summary>
        /// 获取领标单
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocument GetCollarLableDocument(Guid sysNo)
        {
            IQuery query = QueryFactory.Create<CollarLableDocumentQuery>(c => c.SysNo == sysNo);
            return GetCollarLableDocument(query);
        }

        #endregion

        #region 获取领标单列表

        /// <summary>
        /// 获取领标单列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static List<CollarLableDocument> GetCollarLableDocumentList(IQuery query)
        {
            var collarLableDocumentList = collarLableDocumentRepository.GetList(query);
            collarLableDocumentList = LoadOtherObjectData(collarLableDocumentList, query);
            return collarLableDocumentList;
        }

        /// <summary>
        /// 获取领标单列表
        /// </summary>
        /// <param name="collarLableDocumentSysNos">领标单编号</param>
        /// <returns></returns>
        public static List<CollarLableDocument> GetCollarLableDocumentList(IEnumerable<Guid> collarLableDocumentSysNos)
        {
            if (collarLableDocumentSysNos.IsNullOrEmpty())
            {
                return new List<CollarLableDocument>(0);
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentQuery>(c => collarLableDocumentSysNos.Contains(c.SysNo));
            return GetCollarLableDocumentList(query);
        }

        #endregion

        #region 获取领标单分页

        /// <summary>
        /// 获取领标单分页
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static IPaging<CollarLableDocument> GetCollarLableDocumentPaging(IQuery query)
        {
            var collarLableDocumentPaging = collarLableDocumentRepository.GetPaging(query);
            var collarLableDocumentList = LoadOtherObjectData(collarLableDocumentPaging, query);
            return new Paging<CollarLableDocument>(collarLableDocumentPaging.Page, collarLableDocumentPaging.PageSize, collarLableDocumentPaging.TotalCount, collarLableDocumentList);
        }

        #endregion

        #region 加载其它数据

        /// <summary>
        /// 加载其它数据
        /// </summary>
        /// <param name="collarLableDocuments">领标单数据</param>
        /// <param name="query">筛选条件</param>
        /// <returns></returns>
        static List<CollarLableDocument> LoadOtherObjectData(IEnumerable<CollarLableDocument> collarLableDocuments, IQuery query)
        {
            if (collarLableDocuments.IsNullOrEmpty())
            {
                return new List<CollarLableDocument>(0);
            }
            if (query == null)
            {
                return collarLableDocuments.ToList();
            }

            foreach (var collarLableDocument in collarLableDocuments)
            {
                if (collarLableDocument == null)
                {
                    continue;
                }
            }

            return collarLableDocuments.ToList();
        }

        #endregion

        #region 删除领标单

        /// <summary>
        /// 删除领标单
        /// </summary>
        /// <param name="deleteCollarLableDocument">删除信息</param>
        /// <returns>执行结果</returns>
        public static Result DeleteCollarLableDocument(DeleteCollarLableDocument deleteCollarLableDocument)
        {
            var collarLableDocuments = GetCollarLableDocumentList(deleteCollarLableDocument.SysNos);
            collarLableDocuments.ForEach(c => c.Remove());
            return Result.SuccessResult("删除成功");
        }

        #endregion
    }
}
