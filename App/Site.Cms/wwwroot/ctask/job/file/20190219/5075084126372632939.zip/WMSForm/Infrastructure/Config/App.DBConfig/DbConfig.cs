using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Develop.Command;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Extension;
using Microsoft.Extensions.Configuration;
using MicBeach.Util.IoC;
using System.IO;
using WMSForm.Entity.Bcl;
using WMSForm.Query.Bcl;
using MicBeach.Data;
using MicBeach.Data.SqlServer;
using MicBeach.Data.MySQL;

namespace App.DBConfig
{
    /// <summary>
    /// 数据库配置
    /// </summary>
    public class DbConfig
    {
        public static void Init()
        {
            DataBaseEngineConfig();//数据库执行器
            MicBeach.Data.DBConfig.GetDBServerMethod = GetServerInfo;//获取数据连接信息方法
            DataBaseNameConfig();//数据库名设置
            PrimaryKeyConfig();//主键信息配置
            CacheKeysConfig();//缓存信息配置
            CommandExecuteManager.ExectEngine = new DBCommandEngine();
            RefreshFieldsConfig();//刷新字段
        }

        /// <summary>
        /// 数据库执行器配置
        /// </summary>
        static void DataBaseEngineConfig()
        {
            MicBeach.Data.DBConfig.DbEngines.Add(ServerType.SQLServer, new SqlServerEngine());
            MicBeach.Data.DBConfig.DbEngines.Add(ServerType.MySQL, new MySqlEngine());
        }

        /// <summary>
        /// 获取数据库服务器
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private static List<ServerInfo> GetServerInfo(ICommand command)
        {
            List<ServerInfo> servers = new List<ServerInfo>();
            servers.Add(new ServerInfo()
            {
                ServerType = ServerType.SQLServer,
                ConnectionString = File.ReadAllText(Path.Combine(Directory.GetCurrentDirectory(), "dbconfig.txt"))
            });
            return servers;
        }

        /// <summary>
        /// 数据库名设置
        /// </summary>
        static void DataBaseNameConfig()
        {
            QueryConfig.SetObjectName("BCL_CollarLableDocument", typeof(CollarLableDocumentEntity), typeof(CollarLableDocumentQuery));
            QueryConfig.SetObjectName("BCL_CollarLableDocumentProcess", typeof(CollarLableDocumentProcessEntity), typeof(CollarLableDocumentProcessQuery));
            QueryConfig.SetObjectName("BCL_CollarLableDocumentRecord", typeof(CollarLableDocumentRecordEntity), typeof(CollarLableDocumentRecordQuery));
        }

        /// <summary>
        /// 主键配置
        /// </summary>
        static void PrimaryKeyConfig()
        {
            QueryConfig.SetPrimaryKey<CollarLableDocumentEntity>(u => u.SysNo);
            QueryConfig.SetPrimaryKey<CollarLableDocumentProcessEntity>(u => u.SysNo);
            QueryConfig.SetPrimaryKey<CollarLableDocumentRecordEntity>(u => u.SysNo);
        }

        /// <summary>
        /// 缓存键值配置
        /// </summary>
        static void CacheKeysConfig()
        {
        }

        /// <summary>
        /// 刷新字段配置
        /// </summary>
        static void RefreshFieldsConfig()
        {
        }
    }
}
