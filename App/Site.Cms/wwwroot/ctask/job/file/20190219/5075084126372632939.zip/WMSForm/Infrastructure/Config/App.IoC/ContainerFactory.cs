using MicBeach.Util.Drawing;
using MicBeach.Util.IoC;
using MicBeach.Util.Serialize;
using MicBeach.Web.Utility;
using Microsoft.Extensions.DependencyInjection;
using MicBeach.Serialize.Json.JsonNet;
using System;
using System.Collections.Generic;
using System.Linq;
using WMSForm.ServiceContract.Bcl;
using WMSForm.Service.Bcl;
using WMSForm.DataAccess.Bcl;
using WMSForm.BusinessContract.Bcl;
using WMSForm.Business.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Repository.Bcl;
using WMSForm.DataAccessContract.Bcl;
using MicBeach.Web.DI;

namespace App.IoC
{
    public static class ContainerFactory
    {
        /// <summary>
        /// ���ط����ṩ����
        /// </summary>
        /// <returns></returns>
        public static IServiceProvider GetServiceProvider()
        {
            return ServiceProviderConfig.BuildServiceProvider();
        }

        public static void RegisterServices(IServiceCollection services)
        {
            ServiceProviderConfig.RegisterServiceMethod = RegisterTypes;
            ServiceProviderConfig.RegisterServices(services);
            ContainerManager.DefaultServiceCollection = services;
        }

        public static void RegisterTypes()
        {
            var container = new ServiceProviderContainer();

            List<Type> types = new List<Type>();

            #region Sys

            types.AddRange(typeof(ICollarLableDocumentDataAccess).Assembly.GetTypes());
            types.AddRange(typeof(CollarLableDocumentDataAccess).Assembly.GetTypes());
            types.AddRange(typeof(ICollarLableDocumentBusiness).Assembly.GetTypes());
            types.AddRange(typeof(CollarLableDocumentBusiness).Assembly.GetTypes());
            types.AddRange(typeof(ICollarLableDocumentRepository).Assembly.GetTypes());
            types.AddRange(typeof(CollarLableDocumentRepository).Assembly.GetTypes());
            types.AddRange(typeof(ICollarLableDocumentService).Assembly.GetTypes());
            types.AddRange(typeof(CollarLableDocumentService).Assembly.GetTypes());

            #endregion

            foreach (Type type in types)
            {
                string typeName = type.Name;
                if (!typeName.StartsWith("I"))
                {
                    continue;
                }
                if (typeName.EndsWith("Service") || typeName.EndsWith("Business") || typeName.EndsWith("DbAccess") || typeName.EndsWith("Repository"))
                {
                    Type realType = types.FirstOrDefault(t => t.Name != type.Name && !t.IsInterface && type.IsAssignableFrom(t));
                    if (realType != null)
                    {
                        List<Type> behaviors = new List<Type>();
                        container.RegisterType(type, realType, behaviors);
                    }
                }
                if (typeName.EndsWith("DataAccess"))
                {
                    List<Type> relateTypes = types.Where(t => t.Name != type.Name && !t.IsInterface && type.IsAssignableFrom(t)).ToList();
                    if (relateTypes != null && relateTypes.Count > 0)
                    {
                        Type providerType = relateTypes.FirstOrDefault(c => c.Name.EndsWith("Cache"));
                        providerType = providerType ?? relateTypes.First();
                        container.RegisterType(type, providerType);
                    }
                }
            }
            container.RegisterType(typeof(IJsonSerializer), typeof(JsonNetSerializer));
            ContainerManager.Container = container;
        }
    }
}
