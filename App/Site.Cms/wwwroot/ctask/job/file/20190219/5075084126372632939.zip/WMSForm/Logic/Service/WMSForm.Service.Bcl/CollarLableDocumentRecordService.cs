using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.ServiceContract.Bcl;
using WMSForm.BusinessContract.Bcl;

namespace WMSForm.Service.Bcl
{
    /// <summary>
    /// 领表单处理记录服务
    /// </summary>
    public class CollarLableDocumentRecordService : ICollarLableDocumentRecordService
    {
	    ICollarLableDocumentRecordBusiness collarLableDocumentRecordBusiness = null;

		public CollarLableDocumentRecordService(ICollarLableDocumentRecordBusiness collarLableDocumentRecordBusiness)
        {
            this.collarLableDocumentRecordBusiness = collarLableDocumentRecordBusiness;
        }

		#region 保存领表单处理记录

        /// <summary>
        /// 保存领表单处理记录
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentRecordDto> SaveCollarLableDocumentRecord(SaveCollarLableDocumentRecordCmdDto saveInfo)
		{
            return collarLableDocumentRecordBusiness.SaveCollarLableDocumentRecord(saveInfo);
		}

        #endregion

        #region 获取领表单处理记录

        /// <summary>
        /// 获取领表单处理记录
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentRecordDto GetCollarLableDocumentRecord(CollarLableDocumentRecordFilterDto filter)
		{
            return collarLableDocumentRecordBusiness.GetCollarLableDocumentRecord(filter);
		}

        #endregion

        #region 获取领表单处理记录列表

        /// <summary>
        /// 获取领表单处理记录列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordList(CollarLableDocumentRecordFilterDto filter)
		{
			return collarLableDocumentRecordBusiness.GetCollarLableDocumentRecordList(filter); 
		}

        #endregion

		#region 获取领表单处理记录分页

        /// <summary>
        /// 获取领表单处理记录分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordPaging(CollarLableDocumentRecordFilterDto filter)
		{
			return collarLableDocumentRecordBusiness.GetCollarLableDocumentRecordPaging(filter); 
		}

        #endregion

		#region 删除领表单处理记录

        /// <summary>
        /// 删除领表单处理记录
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocumentRecord(DeleteCollarLableDocumentRecordCmdDto deleteInfo)
        {
            return collarLableDocumentRecordBusiness.DeleteCollarLableDocumentRecord(deleteInfo);
        }

        #endregion
    }
}
