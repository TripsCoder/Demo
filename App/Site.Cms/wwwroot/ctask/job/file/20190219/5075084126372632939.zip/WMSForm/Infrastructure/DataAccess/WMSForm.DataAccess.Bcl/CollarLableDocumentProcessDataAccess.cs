using WMSForm.DataAccessContract.Bcl;
using WMSForm.Entity.Bcl;
using MicBeach.Develop.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DataAccess.Bcl
{
    /// <summary>
    /// 领标单处理流程数据访问
    /// </summary>
    public class CollarLableDocumentProcessDataAccess : RdbDataAccess<CollarLableDocumentProcessEntity>, ICollarLableDocumentProcessDbAccess
    {
        #region 获取添加字段

        /// <summary>
        /// 获取添加字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetEditFields()
        {
            return new string[] {"SysNo","LableDocumentSysNo","DepartmentSysNo","DepartmentName","AuditUserSysNo","AuditUserName","SortIndex","FirstAudit","LastAudit","AuditStatus","AuditDate","AuditRemark"};
        }

        #endregion

        #region 获取查询字段

        /// <summary>
        /// 获取查询字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetQueryFields()
        {
            return new string[] {"SysNo","LableDocumentSysNo","DepartmentSysNo","DepartmentName","AuditUserSysNo","AuditUserName","SortIndex","FirstAudit","LastAudit","AuditStatus","AuditDate","AuditRemark"};
        }

        #endregion
    }
}
