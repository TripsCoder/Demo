using WMSForm.DataAccessContract.Bcl;
using WMSForm.Entity.Bcl;
using MicBeach.Develop.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DataAccess.Bcl
{
    /// <summary>
    /// 领标单数据访问
    /// </summary>
    public class CollarLableDocumentDataAccess : RdbDataAccess<CollarLableDocumentEntity>, ICollarLableDocumentDbAccess
    {
        #region 获取添加字段

        /// <summary>
        /// 获取添加字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetEditFields()
        {
            return new string[] {"SysNo","BillNo","BillTitle","BillType","UserSysNo","UserName","EnterpriseName","EnterpriseCode","DepartmentSysNo","DepartmentName","InvoiceType","Remark","BillStatus","LastUpdateDate","SubmitDate","TotalAdjuvantAmount","TotalServiceAmount","PaidAdjuvantAmount","PaidServiceAmount","PaidAmount","LogisticsName","LogisticsNo","BrandSysNo","BrandName","BrandEnterpriseName","BillDescRemark","IsGenerateLableCode","StoreSysNo","StoreName","ApplyYearService",};
        }

        #endregion

        #region 获取查询字段

        /// <summary>
        /// 获取查询字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetQueryFields()
        {
            return new string[] {"SysNo","BillNo","BillTitle","BillType","UserSysNo","UserName","EnterpriseName","EnterpriseCode","DepartmentSysNo","DepartmentName","InvoiceType","Remark","BillStatus","LastUpdateDate","SubmitDate","TotalAdjuvantAmount","TotalServiceAmount","PaidAdjuvantAmount","PaidServiceAmount","PaidAmount","LogisticsName","LogisticsNo","BrandSysNo","BrandName","BrandEnterpriseName","BillDescRemark","IsGenerateLableCode","StoreSysNo","StoreName","ApplyYearService"};
        }

        #endregion
    }
}
