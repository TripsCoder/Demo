using MicBeach.Util.Paging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.ViewModel.Bcl.Filter
{
	/// <summary>
	/// 领标单处理流程查询信息
	/// </summary>
	public class CollarLableDocumentProcessFilterViewModel:PagingFilter
	{
		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public List<Guid> SysNos		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核部门
		/// </summary>
		public Guid DepartmentSysNo		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核用户编号
		/// </summary>
		public Guid AuditUserSysNo		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核用户名称
		/// </summary>
		public string AuditUserName		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核顺序
		/// </summary>
		public int? SortIndex		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 首先审核
		/// </summary>
		public bool? FirstAudit		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 最后审核
		/// </summary>
		public bool? LastAudit		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核状态
		/// </summary>
		public int? AuditStatus		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核时间
		/// </summary>
		public DateTime? AuditDate		
		{
			get;
			set;
		}
		
		/// <summary>
		/// 审核备注
		/// </summary>
		public string AuditRemark		
		{
			get;
			set;
		}
		
		#endregion

		#region 数据加载
				
		#endregion
	}
}