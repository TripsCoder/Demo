using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Util;
using MicBeach.Develop.UnitOfWork;
using MicBeach.Util.Response;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Service;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.BusinessContract.Bcl;
using WMSForm.Domain.Bcl.Service.Request;

namespace WMSForm.Business.Bcl
{
    /// <summary>
    /// 领表单处理记录业务
    /// </summary>
    public class CollarLableDocumentRecordBusiness:ICollarLableDocumentRecordBusiness
    {
        public CollarLableDocumentRecordBusiness()
        {
        }

        #region 保存领表单处理记录

        /// <summary>
        /// 保存领表单处理记录
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentRecordDto> SaveCollarLableDocumentRecord(SaveCollarLableDocumentRecordCmdDto saveInfo)
		{
            if (saveInfo == null)
            {
                return Result<CollarLableDocumentRecordDto>.FailedResult("没有指定任何要保持的信息");
            }
            using (var businessWork = UnitOfWork.Create())
            {
                var saveResult = CollarLableDocumentRecordService.SaveCollarLableDocumentRecord(saveInfo.CollarLableDocumentRecord.MapTo<CollarLableDocumentRecord>());
                if (!saveResult.Success)
                {
                    return Result<CollarLableDocumentRecordDto>.FailedResult(saveResult.Message);
                }
                var commitResult = businessWork.Commit();
                Result<CollarLableDocumentRecordDto> result = null;
                if (commitResult.ExecutedSuccess)
                {
                    result = Result<CollarLableDocumentRecordDto>.SuccessResult("保存成功");
                    result.Data = saveResult.Data.MapTo<CollarLableDocumentRecordDto>();
                }
                else
                {
                    result = Result<CollarLableDocumentRecordDto>.FailedResult("保存失败");
                }
                return result;
            }
		}

        #endregion

        #region 获取领表单处理记录

        /// <summary>
        /// 获取领表单处理记录
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentRecordDto GetCollarLableDocumentRecord(CollarLableDocumentRecordFilterDto filter)
		{
            var collarLableDocumentRecord = CollarLableDocumentRecordService.GetCollarLableDocumentRecord(CreateQueryObject(filter));
            return collarLableDocumentRecord.MapTo<CollarLableDocumentRecordDto>();
		}

        #endregion

        #region 获取领表单处理记录列表

        /// <summary>
        /// 获取领表单处理记录列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordList(CollarLableDocumentRecordFilterDto filter)
		{
			var collarLableDocumentRecordList = CollarLableDocumentRecordService.GetCollarLableDocumentRecordList(CreateQueryObject(filter));
            return collarLableDocumentRecordList.Select(c => c.MapTo<CollarLableDocumentRecordDto>()).ToList();
		}

        #endregion

		#region 获取领表单处理记录分页

        /// <summary>
        /// 获取领表单处理记录分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordPaging(CollarLableDocumentRecordFilterDto filter)
		{
		    var collarLableDocumentRecordPaging = CollarLableDocumentRecordService.GetCollarLableDocumentRecordPaging(CreateQueryObject(filter));
            return collarLableDocumentRecordPaging.ConvertTo<CollarLableDocumentRecordDto>();
		}

        #endregion

		#region 删除领表单处理记录

        /// <summary>
        /// 删除领表单处理记录
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocumentRecord(DeleteCollarLableDocumentRecordCmdDto deleteInfo)
        {
            #region 参数判断

            if (deleteInfo == null || deleteInfo.CollarLableDocumentRecordIds.IsNullOrEmpty())
            {
                return Result.FailedResult("没有指定要删除的领表单处理记录");
            }

            #endregion

            using (var businessWork = UnitOfWork.Create())
            {
                var deleteResult = CollarLableDocumentRecordService.DeleteCollarLableDocumentRecord(deleteInfo.MapTo<DeleteCollarLableDocumentRecord>());
                if (!deleteResult.Success)
                {
                    return deleteResult;
                }
                var commitResult = businessWork.Commit();
                return commitResult.ExecutedSuccess ? Result.SuccessResult("删除成功") : Result.FailedResult("删除失败");
            }
        }

        #endregion

		#region 根据查询条件生成查询对象

        /// <summary>
        /// 根据查询条件生成查询对象
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IQuery CreateQueryObject(CollarLableDocumentRecordFilterDto filter)
        {
            if (filter == null)
            {
                return null;
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentRecordQuery>(filter);

			#region 数据筛选

							if(!filter.SysNos.IsNullOrEmpty())
			{
				query.In<CollarLableDocumentRecordQuery>(c => c.SysNo, filter.SysNos);
			}
            if (!filter.ExcludeSysNos.IsNullOrEmpty())
            {
                query.NotIn<CollarLableDocumentRecordQuery>(c => c.SysNo, filter.ExcludeSysNos);
            }
							            if(!filter.LableDocumentSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentRecordQuery>(c => c.LableDocumentSysNo, filter.LableDocumentSysNo);
			}
            							if(filter.FromStatus.HasValue)
			{
            query.Equal<CollarLableDocumentRecordQuery>(c => c.FromStatus, filter.FromStatus.Value);
			}
										if(filter.ToStatus.HasValue)
			{
            query.Equal<CollarLableDocumentRecordQuery>(c => c.ToStatus, filter.ToStatus.Value);
			}
							            if(!filter.ProcessUserSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentRecordQuery>(c => c.ProcessUserSysNo, filter.ProcessUserSysNo);
			}
            							if(!filter.ProcessUserName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentRecordQuery>(c => c.ProcessUserName, filter.ProcessUserName);
			}
										if(!filter.ProcessRemark.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentRecordQuery>(c => c.ProcessRemark, filter.ProcessRemark);
			}
										if(filter.ProcessDate.HasValue)
			{
            query.Equal<CollarLableDocumentRecordQuery>(c => c.ProcessDate, filter.ProcessDate.Value);
			}
										if(!filter.ClientMsg.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentRecordQuery>(c => c.ClientMsg, filter.ClientMsg);
			}
					
			#endregion

            #region 数据加载


            #endregion

            return query;
        }

        #endregion
    }
}
