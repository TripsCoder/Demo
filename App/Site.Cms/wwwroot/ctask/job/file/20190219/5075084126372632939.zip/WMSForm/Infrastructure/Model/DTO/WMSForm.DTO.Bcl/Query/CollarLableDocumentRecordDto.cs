using System;
using System.Collections.Generic;

namespace WMSForm.DTO.Bcl.Query
{
	/// <summary>
	/// 领表单处理记录
	/// </summary>
	public class CollarLableDocumentRecordDto
	{
		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 源状态
		/// </summary>
		public int FromStatus
		{
			get;
			set;
		}
		
		/// <summary>
		/// 目标状态
		/// </summary>
		public int ToStatus
		{
			get;
			set;
		}
		
		/// <summary>
		/// 处理人
		/// </summary>
		public Guid ProcessUserSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 处理人名称
		/// </summary>
		public string ProcessUserName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 处理备注
		/// </summary>
		public string ProcessRemark
		{
			get;
			set;
		}
		
		/// <summary>
		/// 处理时间
		/// </summary>
		public DateTime ProcessDate
		{
			get;
			set;
		}
		
		/// <summary>
		/// 客户信息
		/// </summary>
		public string ClientMsg
		{
			get;
			set;
		}
		
		#endregion
	}
}