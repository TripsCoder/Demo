using System;
using MicBeach.Develop.Command;
using MicBeach.Util.Extension;

namespace WMSForm.Entity.Bcl
{
	/// <summary>
	/// 领标单处理流程
	/// </summary>
	[Serializable]
	public class CollarLableDocumentProcessEntity:CommandEntity<CollarLableDocumentProcessEntity>
	{
		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get{ return valueDic.GetValue<Guid>("SysNo"); }
			set{ valueDic.SetValue("SysNo", value); }
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo
		{
			get{ return valueDic.GetValue<Guid>("LableDocumentSysNo"); }
			set{ valueDic.SetValue("LableDocumentSysNo", value); }
		}
		
		/// <summary>
		/// 审核部门
		/// </summary>
		public Guid DepartmentSysNo
		{
			get{ return valueDic.GetValue<Guid>("DepartmentSysNo"); }
			set{ valueDic.SetValue("DepartmentSysNo", value); }
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName
		{
			get{ return valueDic.GetValue<string>("DepartmentName"); }
			set{ valueDic.SetValue("DepartmentName", value); }
		}
		
		/// <summary>
		/// 审核用户编号
		/// </summary>
		public Guid AuditUserSysNo
		{
			get{ return valueDic.GetValue<Guid>("AuditUserSysNo"); }
			set{ valueDic.SetValue("AuditUserSysNo", value); }
		}
		
		/// <summary>
		/// 审核用户名称
		/// </summary>
		public string AuditUserName
		{
			get{ return valueDic.GetValue<string>("AuditUserName"); }
			set{ valueDic.SetValue("AuditUserName", value); }
		}
		
		/// <summary>
		/// 审核顺序
		/// </summary>
		public int SortIndex
		{
			get{ return valueDic.GetValue<int>("SortIndex"); }
			set{ valueDic.SetValue("SortIndex", value); }
		}
		
		/// <summary>
		/// 首先审核
		/// </summary>
		public bool FirstAudit
		{
			get{ return valueDic.GetValue<bool>("FirstAudit"); }
			set{ valueDic.SetValue("FirstAudit", value); }
		}
		
		/// <summary>
		/// 最后审核
		/// </summary>
		public bool LastAudit
		{
			get{ return valueDic.GetValue<bool>("LastAudit"); }
			set{ valueDic.SetValue("LastAudit", value); }
		}
		
		/// <summary>
		/// 审核状态
		/// </summary>
		public int AuditStatus
		{
			get{ return valueDic.GetValue<int>("AuditStatus"); }
			set{ valueDic.SetValue("AuditStatus", value); }
		}
		
		/// <summary>
		/// 审核时间
		/// </summary>
		public DateTime AuditDate
		{
			get{ return valueDic.GetValue<DateTime>("AuditDate"); }
			set{ valueDic.SetValue("AuditDate", value); }
		}
		
		/// <summary>
		/// 审核备注
		/// </summary>
		public string AuditRemark
		{
			get{ return valueDic.GetValue<string>("AuditRemark"); }
			set{ valueDic.SetValue("AuditRemark", value); }
		}
		
		#endregion
	}
}