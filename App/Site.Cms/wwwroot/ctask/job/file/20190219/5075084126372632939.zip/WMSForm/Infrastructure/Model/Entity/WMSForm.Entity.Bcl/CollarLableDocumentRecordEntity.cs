using System;
using MicBeach.Develop.Command;
using MicBeach.Util.Extension;

namespace WMSForm.Entity.Bcl
{
	/// <summary>
	/// 领表单处理记录
	/// </summary>
	[Serializable]
	public class CollarLableDocumentRecordEntity:CommandEntity<CollarLableDocumentRecordEntity>
	{
		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get{ return valueDic.GetValue<Guid>("SysNo"); }
			set{ valueDic.SetValue("SysNo", value); }
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo
		{
			get{ return valueDic.GetValue<Guid>("LableDocumentSysNo"); }
			set{ valueDic.SetValue("LableDocumentSysNo", value); }
		}
		
		/// <summary>
		/// 源状态
		/// </summary>
		public int FromStatus
		{
			get{ return valueDic.GetValue<int>("FromStatus"); }
			set{ valueDic.SetValue("FromStatus", value); }
		}
		
		/// <summary>
		/// 目标状态
		/// </summary>
		public int ToStatus
		{
			get{ return valueDic.GetValue<int>("ToStatus"); }
			set{ valueDic.SetValue("ToStatus", value); }
		}
		
		/// <summary>
		/// 处理人
		/// </summary>
		public Guid ProcessUserSysNo
		{
			get{ return valueDic.GetValue<Guid>("ProcessUserSysNo"); }
			set{ valueDic.SetValue("ProcessUserSysNo", value); }
		}
		
		/// <summary>
		/// 处理人名称
		/// </summary>
		public string ProcessUserName
		{
			get{ return valueDic.GetValue<string>("ProcessUserName"); }
			set{ valueDic.SetValue("ProcessUserName", value); }
		}
		
		/// <summary>
		/// 处理备注
		/// </summary>
		public string ProcessRemark
		{
			get{ return valueDic.GetValue<string>("ProcessRemark"); }
			set{ valueDic.SetValue("ProcessRemark", value); }
		}
		
		/// <summary>
		/// 处理时间
		/// </summary>
		public DateTime ProcessDate
		{
			get{ return valueDic.GetValue<DateTime>("ProcessDate"); }
			set{ valueDic.SetValue("ProcessDate", value); }
		}
		
		/// <summary>
		/// 客户信息
		/// </summary>
		public string ClientMsg
		{
			get{ return valueDic.GetValue<string>("ClientMsg"); }
			set{ valueDic.SetValue("ClientMsg", value); }
		}
		
		#endregion
	}
}