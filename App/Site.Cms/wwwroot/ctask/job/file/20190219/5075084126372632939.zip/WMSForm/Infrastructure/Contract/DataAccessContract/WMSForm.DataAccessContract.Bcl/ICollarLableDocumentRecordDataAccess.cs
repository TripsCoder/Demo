using MicBeach.Develop.DataAccess;
using WMSForm.Entity.Bcl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DataAccessContract.Bcl
{
    /// <summary>
    /// 领表单处理记录数据访问接口
    /// </summary>
    public interface ICollarLableDocumentRecordDataAccess:IDataAccess<CollarLableDocumentRecordEntity>
    {
    }

	/// <summary>
    /// 领表单处理记录数据库接口
    /// </summary>
    public interface ICollarLableDocumentRecordDbAccess:ICollarLableDocumentRecordDataAccess
    {
    }
}
