using WMSForm.DataAccessContract.Bcl;
using WMSForm.Entity.Bcl;
using MicBeach.Develop.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DataAccess.Bcl
{
    /// <summary>
    /// 领表单处理记录数据访问
    /// </summary>
    public class CollarLableDocumentRecordDataAccess : RdbDataAccess<CollarLableDocumentRecordEntity>, ICollarLableDocumentRecordDbAccess
    {
        #region 获取添加字段

        /// <summary>
        /// 获取添加字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetEditFields()
        {
            return new string[] {"SysNo","LableDocumentSysNo","FromStatus","ToStatus","ProcessUserSysNo","ProcessUserName","ProcessRemark","ProcessDate","ClientMsg"};
        }

        #endregion

        #region 获取查询字段

        /// <summary>
        /// 获取查询字段
        /// </summary>
        /// <returns></returns>
        protected override string[] GetQueryFields()
        {
            return new string[] {"SysNo","LableDocumentSysNo","FromStatus","ToStatus","ProcessUserSysNo","ProcessUserName","ProcessRemark","ProcessDate","ClientMsg"};
        }

        #endregion
    }
}
