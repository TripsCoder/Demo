using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace App.Mapper
{
    /// <summary>
    /// 显示配置
    /// </summary>
    public static class DisplayConfig
    {
    }
}
