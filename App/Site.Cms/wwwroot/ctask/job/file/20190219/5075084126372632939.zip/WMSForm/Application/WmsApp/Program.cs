﻿using MicBeach.Util.Extension;
using System;
using System.Collections.Generic;
using System.IO;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.ServiceContract.Bcl;
using System.Linq;
using WMSForm.DTO.Bcl.Cmd;
using Site.Cms.Config;
using App.IoC;
using Microsoft.Extensions.DependencyInjection;

namespace WmsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ContainerFactory.RegisterServices(new ServiceCollection());
            AppConfig.Init();
            Console.WriteLine("确认修改输入OK");
            if (Console.ReadLine() != "OK")
            {
                return;
            }
            string filePath = Directory.GetCurrentDirectory();
            filePath = Path.Combine(filePath, "datano.txt");
            if (!File.Exists(filePath))
            {
                Console.WriteLine("数据文件不存在");
            }
            var nos = File.ReadAllLines(filePath);
            var lableService = nos.Instance<ICollarLableDocumentService>();
            var lableRecordService = nos.Instance<ICollarLableDocumentRecordService>();
            var lableAuditService = nos.Instance<ICollarLableDocumentProcessService>();
            var errorNos = new List<string>();
            var beginDate = new DateTime(2018,1,1);
            foreach (var no in nos)
            {
                var doc = lableService.GetCollarLableDocument(new CollarLableDocumentFilterDto()
                {
                    BillNo = no
                });
                if (doc == null)
                {
                    errorNos.Add(no);
                    continue;
                }
                if (doc.LastUpdateDate >= beginDate)
                    continue;
                var nowDateTime = doc.LastUpdateDate;
                var newDate = new DateTime(2018, 1, nowDateTime.Day,nowDateTime.Hour,nowDateTime.Minute,nowDateTime.Second);
                doc.LastUpdateDate = newDate;
                lableService.SaveCollarLableDocument(new SaveCollarLableDocumentCmdDto()
                {
                    CollarLableDocument = doc.MapTo<CollarLableDocumentCmdDto>()
                });
                var recordList = lableRecordService.GetCollarLableDocumentRecordList(new CollarLableDocumentRecordFilterDto()
                {
                    LableDocumentSysNo = doc.SysNo
                });
                var lastTwoRecordList = recordList.OrderByDescending(c => c.ProcessDate).Take(2).ToList();
                foreach (var record in lastTwoRecordList)
                {
                    var nowRecordDate = record.ProcessDate;
                    var newRecordDate = new DateTime(2018, 1, nowRecordDate.Day, nowRecordDate.Hour, nowRecordDate.Minute, nowRecordDate.Second);
                    record.ProcessDate = newRecordDate;
                    lableRecordService.SaveCollarLableDocumentRecord(new SaveCollarLableDocumentRecordCmdDto()
                    {
                        CollarLableDocumentRecord = record.MapTo<CollarLableDocumentRecordCmdDto>()
                    });
                }
                var processList = lableAuditService.GetCollarLableDocumentProcessList(new CollarLableDocumentProcessFilterDto()
                {
                    LableDocumentSysNo = doc.SysNo
                });
                var lastTwoAuditList = processList.OrderByDescending(c => c.SortIndex).Take(2).ToList();
                foreach (var auditRecord in lastTwoAuditList)
                {
                    var nowAuditDate = auditRecord.AuditDate;
                    var newAuditDate = new DateTime(2018, 1, nowAuditDate.Day, nowAuditDate.Hour, nowAuditDate.Minute, nowAuditDate.Second);
                    auditRecord.AuditDate = newAuditDate;
                    lableAuditService.SaveCollarLableDocumentProcess(new SaveCollarLableDocumentProcessCmdDto()
                    {
                        CollarLableDocumentProcess=auditRecord.MapTo<CollarLableDocumentProcessCmdDto>()
                    });
                }
            }

            Console.WriteLine(string.Format("总量：{0},失败总数：{1},失败编码:{2}",nos.Length,errorNos.Count,string.Join("|",errorNos.ToArray())));
            Console.ReadLine();
        }
    }
}
