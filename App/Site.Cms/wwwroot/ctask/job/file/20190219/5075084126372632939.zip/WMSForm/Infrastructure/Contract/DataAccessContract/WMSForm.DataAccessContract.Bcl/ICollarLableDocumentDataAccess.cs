using MicBeach.Develop.DataAccess;
using WMSForm.Entity.Bcl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DataAccessContract.Bcl
{
    /// <summary>
    /// 领标单数据访问接口
    /// </summary>
    public interface ICollarLableDocumentDataAccess:IDataAccess<CollarLableDocumentEntity>
    {
    }

	/// <summary>
    /// 领标单数据库接口
    /// </summary>
    public interface ICollarLableDocumentDbAccess:ICollarLableDocumentDataAccess
    {
    }
}
