using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace App.Mapper
{
    /// <summary>
    /// 数据验证配置
    /// </summary>
    public static class DataValidationConfig
    {
    }
}
