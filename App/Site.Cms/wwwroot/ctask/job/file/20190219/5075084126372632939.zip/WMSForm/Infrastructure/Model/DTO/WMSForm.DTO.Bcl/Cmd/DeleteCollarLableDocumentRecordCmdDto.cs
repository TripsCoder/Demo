using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DTO.Bcl.Cmd
{
    /// <summary>
    /// 删除领表单处理记录
    /// </summary>
    public class DeleteCollarLableDocumentRecordCmdDto
    {
        /// <summary>
        /// 领表单处理记录编号
        /// </summary>
        public IEnumerable<Guid> CollarLableDocumentRecordIds
        {
            get;set;
        }
    }
}
