using System;
using MicBeach.Develop.Command;
using MicBeach.Util.Extension;

namespace WMSForm.Entity.Bcl
{
	/// <summary>
	/// 领标单
	/// </summary>
	[Serializable]
	public class CollarLableDocumentEntity:CommandEntity<CollarLableDocumentEntity>
	{
		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get{ return valueDic.GetValue<Guid>("SysNo"); }
			set{ valueDic.SetValue("SysNo", value); }
		}
		
		/// <summary>
		/// 单据编号
		/// </summary>
		public string BillNo
		{
			get{ return valueDic.GetValue<string>("BillNo"); }
			set{ valueDic.SetValue("BillNo", value); }
		}
		
		/// <summary>
		/// 单据标题
		/// </summary>
		public string BillTitle
		{
			get{ return valueDic.GetValue<string>("BillTitle"); }
			set{ valueDic.SetValue("BillTitle", value); }
		}
		
		/// <summary>
		/// 领标单类型
		/// </summary>
		public int BillType
		{
			get{ return valueDic.GetValue<int>("BillType"); }
			set{ valueDic.SetValue("BillType", value); }
		}
		
		/// <summary>
		/// 提交账号
		/// </summary>
		public Guid UserSysNo
		{
			get{ return valueDic.GetValue<Guid>("UserSysNo"); }
			set{ valueDic.SetValue("UserSysNo", value); }
		}
		
		/// <summary>
		/// 提交用户名
		/// </summary>
		public string UserName
		{
			get{ return valueDic.GetValue<string>("UserName"); }
			set{ valueDic.SetValue("UserName", value); }
		}
		
		/// <summary>
		/// 企业名称
		/// </summary>
		public string EnterpriseName
		{
			get{ return valueDic.GetValue<string>("EnterpriseName"); }
			set{ valueDic.SetValue("EnterpriseName", value); }
		}
		
		/// <summary>
		/// 企业代码
		/// </summary>
		public string EnterpriseCode
		{
			get{ return valueDic.GetValue<string>("EnterpriseCode"); }
			set{ valueDic.SetValue("EnterpriseCode", value); }
		}
		
		/// <summary>
		/// 所属部门
		/// </summary>
		public Guid DepartmentSysNo
		{
			get{ return valueDic.GetValue<Guid>("DepartmentSysNo"); }
			set{ valueDic.SetValue("DepartmentSysNo", value); }
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName
		{
			get{ return valueDic.GetValue<string>("DepartmentName"); }
			set{ valueDic.SetValue("DepartmentName", value); }
		}
		
		/// <summary>
		/// 发票类型
		/// </summary>
		public int InvoiceType
		{
			get{ return valueDic.GetValue<int>("InvoiceType"); }
			set{ valueDic.SetValue("InvoiceType", value); }
		}
		
		/// <summary>
		/// 单据备注
		/// </summary>
		public string Remark
		{
			get{ return valueDic.GetValue<string>("Remark"); }
			set{ valueDic.SetValue("Remark", value); }
		}
		
		/// <summary>
		/// 单据状态
		/// </summary>
		public int BillStatus
		{
			get{ return valueDic.GetValue<int>("BillStatus"); }
			set{ valueDic.SetValue("BillStatus", value); }
		}
		
		/// <summary>
		/// 最近更新时间
		/// </summary>
		public DateTime LastUpdateDate
		{
			get{ return valueDic.GetValue<DateTime>("LastUpdateDate"); }
			set{ valueDic.SetValue("LastUpdateDate", value); }
		}
		
		/// <summary>
		/// 提交时间
		/// </summary>
		public DateTime SubmitDate
		{
			get{ return valueDic.GetValue<DateTime>("SubmitDate"); }
			set{ valueDic.SetValue("SubmitDate", value); }
		}
		
		/// <summary>
		/// 辅料费总计
		/// </summary>
		public decimal TotalAdjuvantAmount
		{
			get{ return valueDic.GetValue<decimal>("TotalAdjuvantAmount"); }
			set{ valueDic.SetValue("TotalAdjuvantAmount", value); }
		}
		
		/// <summary>
		/// 服务费总计
		/// </summary>
		public decimal TotalServiceAmount
		{
			get{ return valueDic.GetValue<decimal>("TotalServiceAmount"); }
			set{ valueDic.SetValue("TotalServiceAmount", value); }
		}
		
		/// <summary>
		/// 支付辅料费
		/// </summary>
		public decimal PaidAdjuvantAmount
		{
			get{ return valueDic.GetValue<decimal>("PaidAdjuvantAmount"); }
			set{ valueDic.SetValue("PaidAdjuvantAmount", value); }
		}
		
		/// <summary>
		/// 支付服务费
		/// </summary>
		public decimal PaidServiceAmount
		{
			get{ return valueDic.GetValue<decimal>("PaidServiceAmount"); }
			set{ valueDic.SetValue("PaidServiceAmount", value); }
		}
		
		/// <summary>
		/// 已付金额
		/// </summary>
		public decimal PaidAmount
		{
			get{ return valueDic.GetValue<decimal>("PaidAmount"); }
			set{ valueDic.SetValue("PaidAmount", value); }
		}
		
		/// <summary>
		/// 物流公司
		/// </summary>
		public string LogisticsName
		{
			get{ return valueDic.GetValue<string>("LogisticsName"); }
			set{ valueDic.SetValue("LogisticsName", value); }
		}
		
		/// <summary>
		/// 物流编号
		/// </summary>
		public string LogisticsNo
		{
			get{ return valueDic.GetValue<string>("LogisticsNo"); }
			set{ valueDic.SetValue("LogisticsNo", value); }
		}
		
		/// <summary>
		/// 品牌
		/// </summary>
		public Guid BrandSysNo
		{
			get{ return valueDic.GetValue<Guid>("BrandSysNo"); }
			set{ valueDic.SetValue("BrandSysNo", value); }
		}
		
		/// <summary>
		/// 品牌名
		/// </summary>
		public string BrandName
		{
			get{ return valueDic.GetValue<string>("BrandName"); }
			set{ valueDic.SetValue("BrandName", value); }
		}
		
		/// <summary>
		/// 品牌企业名
		/// </summary>
		public string BrandEnterpriseName
		{
			get{ return valueDic.GetValue<string>("BrandEnterpriseName"); }
			set{ valueDic.SetValue("BrandEnterpriseName", value); }
		}
		
		/// <summary>
		/// 单据信息说明
		/// </summary>
		public string BillDescRemark
		{
			get{ return valueDic.GetValue<string>("BillDescRemark"); }
			set{ valueDic.SetValue("BillDescRemark", value); }
		}
		
		/// <summary>
		/// 是否生成了领标码
		/// </summary>
		public bool IsGenerateLableCode
		{
			get{ return valueDic.GetValue<bool>("IsGenerateLableCode"); }
			set{ valueDic.SetValue("IsGenerateLableCode", value); }
		}
		
		/// <summary>
		/// 所属店铺
		/// </summary>
		public Guid StoreSysNo
		{
			get{ return valueDic.GetValue<Guid>("StoreSysNo"); }
			set{ valueDic.SetValue("StoreSysNo", value); }
		}
		
		/// <summary>
		/// 店铺名
		/// </summary>
		public string StoreName
		{
			get{ return valueDic.GetValue<string>("StoreName"); }
			set{ valueDic.SetValue("StoreName", value); }
		}
		
		/// <summary>
		/// 应用了年度服务费
		/// </summary>
		public bool ApplyYearService
		{
			get{ return valueDic.GetValue<bool>("ApplyYearService"); }
			set{ valueDic.SetValue("ApplyYearService", value); }
		}
		
		/// <summary>
		/// 版本号
		/// </summary>
		public long VersionNo
		{
			get{ return valueDic.GetValue<long>("VersionNo"); }
			set{ valueDic.SetValue("VersionNo", value); }
		}
		
		#endregion
	}
}