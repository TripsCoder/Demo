using System;
using System.Collections.Generic;
using System.Text;

namespace Site.Cms.Config
{
    public static class MvcConfig
    {
        public static void Init()
        {
        }
    }
}