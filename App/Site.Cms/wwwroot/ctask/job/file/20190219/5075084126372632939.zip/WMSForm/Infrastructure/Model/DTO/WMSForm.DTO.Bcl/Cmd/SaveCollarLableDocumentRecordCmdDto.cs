using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DTO.Bcl.Cmd
{
    /// <summary>
    /// 保存领表单处理记录信息
    /// </summary>
    public class SaveCollarLableDocumentRecordCmdDto
    {
        /// <summary>
        /// 领表单处理记录信息
        /// </summary>
        public CollarLableDocumentRecordCmdDto CollarLableDocumentRecord
        {
            get;set;
        }
    }
}
