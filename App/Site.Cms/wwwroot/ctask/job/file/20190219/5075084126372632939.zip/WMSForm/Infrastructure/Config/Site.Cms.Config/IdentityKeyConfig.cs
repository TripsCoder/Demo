using MicBeach.Util.Code;
using System;
using System.Collections.Generic;
using System.Text;

namespace Site.Cms.Config
{
    /// <summary>
    /// 唯一标识符配置
    /// </summary>
    public static class IdentityKeyConfig
    {
        public static void Init()
        {
            List<string> groupCodes = new List<string>();


            SerialNumber.RegisterGenerator(groupCodes, 1, 1);
        }
    }
}