using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using MicBeach.Util;
using MicBeach.Util.Response;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;

namespace WMSForm.BusinessContract.Bcl
{
    /// <summary>
    /// 领标单业务接口
    /// </summary>
    public interface ICollarLableDocumentBusiness
    {
        #region 保存领标单

        /// <summary>
        /// 保存领标单
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        Result<CollarLableDocumentDto> SaveCollarLableDocument(SaveCollarLableDocumentCmdDto saveInfo);

        #endregion

        #region 获取领标单

        /// <summary>
        /// 获取领标单
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        CollarLableDocumentDto GetCollarLableDocument(CollarLableDocumentFilterDto filter);

        #endregion

        #region 获取领标单列表

        /// <summary>
        /// 获取领标单列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        List<CollarLableDocumentDto> GetCollarLableDocumentList(CollarLableDocumentFilterDto filter);

        #endregion

		#region 获取领标单分页

        /// <summary>
        /// 获取领标单分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IPaging<CollarLableDocumentDto> GetCollarLableDocumentPaging(CollarLableDocumentFilterDto filter);

        #endregion

		#region 删除领标单

        /// <summary>
        /// 删除领标单
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        Result DeleteCollarLableDocument(DeleteCollarLableDocumentCmdDto deleteInfo);

        #endregion
    }
}
