using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using MicBeach.Develop.Domain.Repository;
using WMSForm.Domain.Bcl.Model;

namespace WMSForm.Domain.Bcl.Repository
{
    /// <summary>
    /// 领标单存储
    /// </summary>
    public interface ICollarLableDocumentRepository : IRepository<CollarLableDocument>
    {
    }
}