using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.ServiceContract.Bcl;
using WMSForm.BusinessContract.Bcl;

namespace WMSForm.Service.Bcl
{
    /// <summary>
    /// 领标单服务
    /// </summary>
    public class CollarLableDocumentService : ICollarLableDocumentService
    {
	    ICollarLableDocumentBusiness collarLableDocumentBusiness = null;

		public CollarLableDocumentService(ICollarLableDocumentBusiness collarLableDocumentBusiness)
        {
            this.collarLableDocumentBusiness = collarLableDocumentBusiness;
        }

		#region 保存领标单

        /// <summary>
        /// 保存领标单
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentDto> SaveCollarLableDocument(SaveCollarLableDocumentCmdDto saveInfo)
		{
            return collarLableDocumentBusiness.SaveCollarLableDocument(saveInfo);
		}

        #endregion

        #region 获取领标单

        /// <summary>
        /// 获取领标单
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentDto GetCollarLableDocument(CollarLableDocumentFilterDto filter)
		{
            return collarLableDocumentBusiness.GetCollarLableDocument(filter);
		}

        #endregion

        #region 获取领标单列表

        /// <summary>
        /// 获取领标单列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentDto> GetCollarLableDocumentList(CollarLableDocumentFilterDto filter)
		{
			return collarLableDocumentBusiness.GetCollarLableDocumentList(filter); 
		}

        #endregion

		#region 获取领标单分页

        /// <summary>
        /// 获取领标单分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentDto> GetCollarLableDocumentPaging(CollarLableDocumentFilterDto filter)
		{
			return collarLableDocumentBusiness.GetCollarLableDocumentPaging(filter); 
		}

        #endregion

		#region 删除领标单

        /// <summary>
        /// 删除领标单
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocument(DeleteCollarLableDocumentCmdDto deleteInfo)
        {
            return collarLableDocumentBusiness.DeleteCollarLableDocument(deleteInfo);
        }

        #endregion
    }
}
