using System;
using System.Collections.Generic;
using MicBeach.Develop.Domain.Aggregation;
using MicBeach.Util;
using MicBeach.Util.Extension;
using MicBeach.Util.Code;
using MicBeach.Util.Data;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Response;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Domain.Bcl.Service;
using System.Threading.Tasks;

namespace WMSForm.Domain.Bcl.Model
{
	/// <summary>
	/// 领表单处理记录
	/// </summary>
	public class CollarLableDocumentRecord:AggregationRoot<CollarLableDocumentRecord>
	{
		ICollarLableDocumentRecordRepository collarLableDocumentRecordRepository = null;

		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		protected Guid _sysNo;
		
		/// <summary>
		/// 领标单号
		/// </summary>
		protected Guid _lableDocumentSysNo;
		
		/// <summary>
		/// 源状态
		/// </summary>
		protected int _fromStatus;
		
		/// <summary>
		/// 目标状态
		/// </summary>
		protected int _toStatus;
		
		/// <summary>
		/// 处理人
		/// </summary>
		protected Guid _processUserSysNo;
		
		/// <summary>
		/// 处理人名称
		/// </summary>
		protected string _processUserName;
		
		/// <summary>
		/// 处理备注
		/// </summary>
		protected string _processRemark;
		
		/// <summary>
		/// 处理时间
		/// </summary>
		protected DateTime _processDate;
		
		/// <summary>
		/// 客户信息
		/// </summary>
		protected string _clientMsg;
		
		#endregion

		#region 构造方法

		/// <summary>
		/// 实例化领表单处理记录对象
		/// </summary>
		/// <param name="sysNo">编号</param>
        internal CollarLableDocumentRecord()
        {
            collarLableDocumentRecordRepository=this.Instance<ICollarLableDocumentRecordRepository>();
					}

		#endregion

		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get
			{
				return _sysNo;
			}
			protected set
			{
				_sysNo=value;
			}
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo
		{
			get
			{
				return _lableDocumentSysNo;
			}
			protected set
			{
				_lableDocumentSysNo=value;
			}
		}
		
		/// <summary>
		/// 源状态
		/// </summary>
		public int FromStatus
		{
			get
			{
				return _fromStatus;
			}
			protected set
			{
				_fromStatus=value;
			}
		}
		
		/// <summary>
		/// 目标状态
		/// </summary>
		public int ToStatus
		{
			get
			{
				return _toStatus;
			}
			protected set
			{
				_toStatus=value;
			}
		}
		
		/// <summary>
		/// 处理人
		/// </summary>
		public Guid ProcessUserSysNo
		{
			get
			{
				return _processUserSysNo;
			}
			protected set
			{
				_processUserSysNo=value;
			}
		}
		
		/// <summary>
		/// 处理人名称
		/// </summary>
		public string ProcessUserName
		{
			get
			{
				return _processUserName;
			}
			protected set
			{
				_processUserName=value;
			}
		}
		
		/// <summary>
		/// 处理备注
		/// </summary>
		public string ProcessRemark
		{
			get
			{
				return _processRemark;
			}
			protected set
			{
				_processRemark=value;
			}
		}
		
		/// <summary>
		/// 处理时间
		/// </summary>
		public DateTime ProcessDate
		{
			get
			{
				return _processDate;
			}
			set
			{
				_processDate=value;
			}
		}
		
		/// <summary>
		/// 客户信息
		/// </summary>
		public string ClientMsg
		{
			get
			{
				return _clientMsg;
			}
			protected set
			{
				_clientMsg=value;
			}
		}
		
		#endregion

		#region 方法

		#region 功能方法

		#region 保存

		/// <summary>
		/// 保存
		/// </summary>
		public override async Task SaveAsync()
		{
            await collarLableDocumentRecordRepository.SaveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region	移除

		/// <summary>
		/// 移除
		/// </summary>
		public override async Task RemoveAsync()
		{
            await collarLableDocumentRecordRepository.RemoveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region 初始化标识信息

		/// <summary>
		/// 初始化标识信息
		/// </summary>
		public override void InitPrimaryValue()
		{
            base.InitPrimaryValue();
                        _sysNo = GenerateCollarLableDocumentRecordSysNo();
            		}

        #endregion

        #region 判断标识对象值是否为空

        /// <summary>
        /// 判断标识对象值是否为空
        /// </summary>
        /// <returns></returns>
        public override bool PrimaryValueIsNone()
        {
            return _sysNo.IsEmpty();
        }

        #endregion

        #region 判断领表单处理记录相等

        /// <summary>
        /// 判断领表单处理记录对象是否相等
        /// </summary>
        /// <param name="obj">另一个领表单处理记录对象</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is CollarLableDocumentRecord))
            {
                return false;
            }
            var otherCollarLableDocumentRecord = obj as CollarLableDocumentRecord;
            return _sysNo == otherCollarLableDocumentRecord.SysNo;
        }

        /// <summary>
        /// get hash code
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return 0;
        }

        #endregion


        #endregion

        #region 内部方法


        #endregion

        #region 静态方法

        #region 生成一个领表单处理记录编号

        /// <summary>
        /// 生成一个领表单处理记录编号
        /// </summary>
        /// <returns></returns>
        public static Guid GenerateCollarLableDocumentRecordSysNo()
        {
            return Guid.NewGuid();
        }

        #endregion

        #region 创建领表单处理记录

        /// <summary>
        /// 创建一个领表单处理记录对象
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocumentRecord CreateCollarLableDocumentRecord(Guid sysNo)
        {
            sysNo = sysNo.IsEmpty() ? GenerateCollarLableDocumentRecordSysNo() : sysNo;
            return new CollarLableDocumentRecord()
            {
                SysNo=sysNo
            };
        }

        #endregion

        #endregion

        #endregion
	}
}