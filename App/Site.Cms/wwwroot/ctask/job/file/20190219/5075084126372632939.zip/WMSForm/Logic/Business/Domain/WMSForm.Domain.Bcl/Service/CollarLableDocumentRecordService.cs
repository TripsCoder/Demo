using System;
using System.Collections.Generic;
using System.Linq;
using MicBeach.Util.Extension;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using MicBeach.Util.IoC;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Service.Request;
using MicBeach.Develop.CQuery;

namespace WMSForm.Domain.Bcl.Service
{
    /// <summary>
    /// 领表单处理记录服务
    /// </summary>
    public static class CollarLableDocumentRecordService
    {
        static ICollarLableDocumentRecordRepository collarLableDocumentRecordRepository = ContainerManager.Container.Resolve<ICollarLableDocumentRecordRepository>();

        #region 保存

        /// <summary>
        /// 保存领表单处理记录
        /// </summary>
        /// <param name="collarLableDocumentRecord">领表单处理记录信息</param>
        /// <returns></returns>
        public static Result<CollarLableDocumentRecord> SaveCollarLableDocumentRecord(CollarLableDocumentRecord collarLableDocumentRecord)
        {
            if (collarLableDocumentRecord == null)
            {
                return Result<CollarLableDocumentRecord>.FailedResult("领表单处理记录信息为空");
            }
            if (collarLableDocumentRecord.PrimaryValueIsNone())
            {
                return AddCollarLableDocumentRecord(collarLableDocumentRecord);
            }
            else
            {
                return EditCollarLableDocumentRecord(collarLableDocumentRecord);
            }
        }

        /// <summary>
        /// 添加领表单处理记录
        /// </summary>
        /// <param name="collarLableDocumentRecord">领表单处理记录对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocumentRecord> AddCollarLableDocumentRecord(CollarLableDocumentRecord collarLableDocumentRecord)
        {
            #region 参数判断

            if (collarLableDocumentRecord == null)
            {
                return Result<CollarLableDocumentRecord>.FailedResult("没有指定要添加的领表单处理记录数据");
            }

            #endregion

            collarLableDocumentRecord.Save();
            var result = Result<CollarLableDocumentRecord>.SuccessResult("添加成功");
            result.Data = collarLableDocumentRecord;
            return result;
        }

        /// <summary>
        /// 编辑领表单处理记录
        /// </summary>
        /// <param name="newCollarLableDocumentRecord">领表单处理记录对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocumentRecord> EditCollarLableDocumentRecord(CollarLableDocumentRecord newCollarLableDocumentRecord)
        {
            #region 参数判断

            if (newCollarLableDocumentRecord == null)
            {
                return Result<CollarLableDocumentRecord>.FailedResult("没有指定要操作的领表单处理记录信息");
            }

            #endregion

            CollarLableDocumentRecord collarLableDocumentRecord = collarLableDocumentRecordRepository.Get(QueryFactory.Create<CollarLableDocumentRecordQuery>(r => r.SysNo == newCollarLableDocumentRecord.SysNo));
            if (collarLableDocumentRecord == null)
            {
                return Result<CollarLableDocumentRecord>.FailedResult("没有指定要操作的领表单处理记录信息");
            }
            //修改信息
            collarLableDocumentRecord.ProcessDate = newCollarLableDocumentRecord.ProcessDate;
            collarLableDocumentRecord.Save();
            var result = Result<CollarLableDocumentRecord>.SuccessResult("修改成功");
            result.Data = collarLableDocumentRecord;
            return result;
        }

        #endregion

        #region 获取领表单处理记录

        /// <summary>
        /// 获取领表单处理记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static CollarLableDocumentRecord GetCollarLableDocumentRecord(IQuery query)
        {
            var collarLableDocumentRecord = collarLableDocumentRecordRepository.Get(query);
            return collarLableDocumentRecord;
        }

        /// <summary>
        /// 获取领表单处理记录
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocumentRecord GetCollarLableDocumentRecord(Guid sysNo)
        {
            IQuery query = QueryFactory.Create<CollarLableDocumentRecordQuery>(c => c.SysNo == sysNo);
            return GetCollarLableDocumentRecord(query);
        }

        #endregion

        #region 获取领表单处理记录列表

        /// <summary>
        /// 获取领表单处理记录列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static List<CollarLableDocumentRecord> GetCollarLableDocumentRecordList(IQuery query)
        {
            var collarLableDocumentRecordList = collarLableDocumentRecordRepository.GetList(query);
            collarLableDocumentRecordList = LoadOtherObjectData(collarLableDocumentRecordList, query);
            return collarLableDocumentRecordList;
        }

        /// <summary>
        /// 获取领表单处理记录列表
        /// </summary>
        /// <param name="collarLableDocumentRecordSysNos">领表单处理记录编号</param>
        /// <returns></returns>
        public static List<CollarLableDocumentRecord> GetCollarLableDocumentRecordList(IEnumerable<Guid> collarLableDocumentRecordSysNos)
        {
            if (collarLableDocumentRecordSysNos.IsNullOrEmpty())
            {
                return new List<CollarLableDocumentRecord>(0);
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentRecordQuery>(c => collarLableDocumentRecordSysNos.Contains(c.SysNo));
            return GetCollarLableDocumentRecordList(query);
        }

        #endregion

        #region 获取领表单处理记录分页

        /// <summary>
        /// 获取领表单处理记录分页
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static IPaging<CollarLableDocumentRecord> GetCollarLableDocumentRecordPaging(IQuery query)
        {
            var collarLableDocumentRecordPaging = collarLableDocumentRecordRepository.GetPaging(query);
            var collarLableDocumentRecordList = LoadOtherObjectData(collarLableDocumentRecordPaging, query);
            return new Paging<CollarLableDocumentRecord>(collarLableDocumentRecordPaging.Page, collarLableDocumentRecordPaging.PageSize, collarLableDocumentRecordPaging.TotalCount, collarLableDocumentRecordList);
        }

        #endregion

        #region 加载其它数据

        /// <summary>
        /// 加载其它数据
        /// </summary>
        /// <param name="collarLableDocumentRecords">领表单处理记录数据</param>
        /// <param name="query">筛选条件</param>
        /// <returns></returns>
        static List<CollarLableDocumentRecord> LoadOtherObjectData(IEnumerable<CollarLableDocumentRecord> collarLableDocumentRecords, IQuery query)
        {
            if (collarLableDocumentRecords.IsNullOrEmpty())
            {
                return new List<CollarLableDocumentRecord>(0);
            }
            if (query == null)
            {
                return collarLableDocumentRecords.ToList();
            }

            foreach (var collarLableDocumentRecord in collarLableDocumentRecords)
            {
                if (collarLableDocumentRecord == null)
                {
                    continue;
                }
            }

            return collarLableDocumentRecords.ToList();
        }

        #endregion

        #region 删除领表单处理记录

        /// <summary>
        /// 删除领表单处理记录
        /// </summary>
        /// <param name="deleteCollarLableDocumentRecord">删除信息</param>
        /// <returns>执行结果</returns>
        public static Result DeleteCollarLableDocumentRecord(DeleteCollarLableDocumentRecord deleteCollarLableDocumentRecord)
        {
            var collarLableDocumentRecords = GetCollarLableDocumentRecordList(deleteCollarLableDocumentRecord.SysNos);
            collarLableDocumentRecords.ForEach(c => c.Remove());
            return Result.SuccessResult("删除成功");
        }

        #endregion
    }
}
