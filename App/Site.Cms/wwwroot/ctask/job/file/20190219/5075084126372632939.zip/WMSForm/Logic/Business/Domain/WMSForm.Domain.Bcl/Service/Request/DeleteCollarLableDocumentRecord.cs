using System;
using System.Collections.Generic;
using System.Text;

namespace WMSForm.Domain.Bcl.Service.Request
{
    /// <summary>
    /// 删除领表单处理记录
    /// </summary>
    public class DeleteCollarLableDocumentRecord
    {
        /// <summary>
        /// 领表单处理记录编号
        /// </summary>
        public List<Guid> SysNos
        {
            get;set;
        }
    }
}
