using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DTO.Bcl.Cmd
{
    /// <summary>
    /// 删除领标单
    /// </summary>
    public class DeleteCollarLableDocumentCmdDto
    {
        /// <summary>
        /// 领标单编号
        /// </summary>
        public IEnumerable<Guid> CollarLableDocumentIds
        {
            get;set;
        }
    }
}
