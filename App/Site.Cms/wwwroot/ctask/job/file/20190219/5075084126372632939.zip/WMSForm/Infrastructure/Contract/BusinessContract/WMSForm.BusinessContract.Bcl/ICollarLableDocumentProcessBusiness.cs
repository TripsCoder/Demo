using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using MicBeach.Util;
using MicBeach.Util.Response;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;

namespace WMSForm.BusinessContract.Bcl
{
    /// <summary>
    /// 领标单处理流程业务接口
    /// </summary>
    public interface ICollarLableDocumentProcessBusiness
    {
        #region 保存领标单处理流程

        /// <summary>
        /// 保存领标单处理流程
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        Result<CollarLableDocumentProcessDto> SaveCollarLableDocumentProcess(SaveCollarLableDocumentProcessCmdDto saveInfo);

        #endregion

        #region 获取领标单处理流程

        /// <summary>
        /// 获取领标单处理流程
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        CollarLableDocumentProcessDto GetCollarLableDocumentProcess(CollarLableDocumentProcessFilterDto filter);

        #endregion

        #region 获取领标单处理流程列表

        /// <summary>
        /// 获取领标单处理流程列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        List<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessList(CollarLableDocumentProcessFilterDto filter);

        #endregion

		#region 获取领标单处理流程分页

        /// <summary>
        /// 获取领标单处理流程分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IPaging<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessPaging(CollarLableDocumentProcessFilterDto filter);

        #endregion

		#region 删除领标单处理流程

        /// <summary>
        /// 删除领标单处理流程
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        Result DeleteCollarLableDocumentProcess(DeleteCollarLableDocumentProcessCmdDto deleteInfo);

        #endregion
    }
}
