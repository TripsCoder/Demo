using System;
using System.Collections.Generic;
using MicBeach.Develop.CQuery;

namespace WMSForm.Query.Bcl
{
	/// <summary>
	/// 领标单
	/// </summary>
	public class CollarLableDocumentQuery:IQueryModel<CollarLableDocumentQuery>
	{
		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 单据编号
		/// </summary>
		public string BillNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 单据标题
		/// </summary>
		public string BillTitle
		{
			get;
			set;
		}
		
		/// <summary>
		/// 领标单类型
		/// </summary>
		public int BillType
		{
			get;
			set;
		}
		
		/// <summary>
		/// 提交账号
		/// </summary>
		public Guid UserSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 提交用户名
		/// </summary>
		public string UserName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 企业名称
		/// </summary>
		public string EnterpriseName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 企业代码
		/// </summary>
		public string EnterpriseCode
		{
			get;
			set;
		}
		
		/// <summary>
		/// 所属部门
		/// </summary>
		public Guid DepartmentSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 发票类型
		/// </summary>
		public int InvoiceType
		{
			get;
			set;
		}
		
		/// <summary>
		/// 单据备注
		/// </summary>
		public string Remark
		{
			get;
			set;
		}
		
		/// <summary>
		/// 单据状态
		/// </summary>
		public int BillStatus
		{
			get;
			set;
		}
		
		/// <summary>
		/// 最近更新时间
		/// </summary>
		public DateTime LastUpdateDate
		{
			get;
			set;
		}
		
		/// <summary>
		/// 提交时间
		/// </summary>
		public DateTime SubmitDate
		{
			get;
			set;
		}
		
		/// <summary>
		/// 辅料费总计
		/// </summary>
		public decimal TotalAdjuvantAmount
		{
			get;
			set;
		}
		
		/// <summary>
		/// 服务费总计
		/// </summary>
		public decimal TotalServiceAmount
		{
			get;
			set;
		}
		
		/// <summary>
		/// 支付辅料费
		/// </summary>
		public decimal PaidAdjuvantAmount
		{
			get;
			set;
		}
		
		/// <summary>
		/// 支付服务费
		/// </summary>
		public decimal PaidServiceAmount
		{
			get;
			set;
		}
		
		/// <summary>
		/// 已付金额
		/// </summary>
		public decimal PaidAmount
		{
			get;
			set;
		}
		
		/// <summary>
		/// 物流公司
		/// </summary>
		public string LogisticsName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 物流编号
		/// </summary>
		public string LogisticsNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 品牌
		/// </summary>
		public Guid BrandSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 品牌名
		/// </summary>
		public string BrandName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 品牌企业名
		/// </summary>
		public string BrandEnterpriseName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 单据信息说明
		/// </summary>
		public string BillDescRemark
		{
			get;
			set;
		}
		
		/// <summary>
		/// 是否生成了领标码
		/// </summary>
		public bool IsGenerateLableCode
		{
			get;
			set;
		}
		
		/// <summary>
		/// 所属店铺
		/// </summary>
		public Guid StoreSysNo
		{
			get;
			set;
		}
		
		/// <summary>
		/// 店铺名
		/// </summary>
		public string StoreName
		{
			get;
			set;
		}
		
		/// <summary>
		/// 应用了年度服务费
		/// </summary>
		public bool ApplyYearService
		{
			get;
			set;
		}
		
		/// <summary>
		/// 版本号
		/// </summary>
		public long VersionNo
		{
			get;
			set;
		}
		
		#endregion
	}
}