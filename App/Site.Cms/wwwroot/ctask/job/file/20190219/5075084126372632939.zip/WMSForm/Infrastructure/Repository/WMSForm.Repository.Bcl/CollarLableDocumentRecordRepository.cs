using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Develop.CQuery;
using MicBeach.Develop.Domain.Repository;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Entity.Bcl;
using WMSForm.Query.Bcl;
using WMSForm.DataAccessContract.Bcl;


namespace WMSForm.Repository.Bcl
{
    /// <summary>
    /// 领表单处理记录存储
    /// </summary>
    public class CollarLableDocumentRecordRepository : DefaultRepository<CollarLableDocumentRecord, CollarLableDocumentRecordEntity, ICollarLableDocumentRecordDataAccess>,ICollarLableDocumentRecordRepository
    {
    }
}
