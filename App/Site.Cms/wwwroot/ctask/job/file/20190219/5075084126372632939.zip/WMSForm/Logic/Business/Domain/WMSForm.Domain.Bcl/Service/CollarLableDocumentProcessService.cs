using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using MicBeach.Util;
using MicBeach.Util.IoC;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Service.Request;

namespace WMSForm.Domain.Bcl.Service
{
    /// <summary>
    /// 领标单处理流程服务
    /// </summary>
    public static class CollarLableDocumentProcessService
    {
        static ICollarLableDocumentProcessRepository collarLableDocumentProcessRepository = ContainerManager.Container.Resolve<ICollarLableDocumentProcessRepository>();

        #region 保存

        /// <summary>
        /// 保存领标单处理流程
        /// </summary>
        /// <param name="collarLableDocumentProcess">领标单处理流程信息</param>
        /// <returns></returns>
        public static Result<CollarLableDocumentProcess> SaveCollarLableDocumentProcess(CollarLableDocumentProcess collarLableDocumentProcess)
        {
            if (collarLableDocumentProcess == null)
            {
                return Result<CollarLableDocumentProcess>.FailedResult("领标单处理流程信息为空");
            }
            if (collarLableDocumentProcess.PrimaryValueIsNone())
            {
                return AddCollarLableDocumentProcess(collarLableDocumentProcess);
            }
            else
            {
                return EditCollarLableDocumentProcess(collarLableDocumentProcess);
            }
        }

        /// <summary>
        /// 添加领标单处理流程
        /// </summary>
        /// <param name="collarLableDocumentProcess">领标单处理流程对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocumentProcess> AddCollarLableDocumentProcess(CollarLableDocumentProcess collarLableDocumentProcess)
        {
            #region 参数判断

            if (collarLableDocumentProcess == null)
            {
                return Result<CollarLableDocumentProcess>.FailedResult("没有指定要添加的领标单处理流程数据");
            }

            #endregion

            collarLableDocumentProcess.Save();
            var result = Result<CollarLableDocumentProcess>.SuccessResult("添加成功");
            result.Data = collarLableDocumentProcess;
            return result;
        }

        /// <summary>
        /// 编辑领标单处理流程
        /// </summary>
        /// <param name="newCollarLableDocumentProcess">领标单处理流程对象</param>
        /// <returns>执行结果</returns>
        static Result<CollarLableDocumentProcess> EditCollarLableDocumentProcess(CollarLableDocumentProcess newCollarLableDocumentProcess)
        {
            #region 参数判断

            if (newCollarLableDocumentProcess == null)
            {
                return Result<CollarLableDocumentProcess>.FailedResult("没有指定要操作的领标单处理流程信息");
            }

            #endregion

            CollarLableDocumentProcess collarLableDocumentProcess = collarLableDocumentProcessRepository.Get(QueryFactory.Create<CollarLableDocumentProcessQuery>(r => r.SysNo == newCollarLableDocumentProcess.SysNo));
            if (collarLableDocumentProcess == null)
            {
                return Result<CollarLableDocumentProcess>.FailedResult("没有指定要操作的领标单处理流程信息");
            }
            //修改信息
            collarLableDocumentProcess.AuditDate = newCollarLableDocumentProcess.AuditDate;
            collarLableDocumentProcess.Save();
            var result = Result<CollarLableDocumentProcess>.SuccessResult("修改成功");
            result.Data = collarLableDocumentProcess;
            return result;
        }

        #endregion

        #region 获取领标单处理流程

        /// <summary>
        /// 获取领标单处理流程
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static CollarLableDocumentProcess GetCollarLableDocumentProcess(IQuery query)
        {
            var collarLableDocumentProcess = collarLableDocumentProcessRepository.Get(query);
            return collarLableDocumentProcess;
        }

        /// <summary>
        /// 获取领标单处理流程
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocumentProcess GetCollarLableDocumentProcess(Guid sysNo)
        {
            IQuery query = QueryFactory.Create<CollarLableDocumentProcessQuery>(c => c.SysNo == sysNo);
            return GetCollarLableDocumentProcess(query);
        }

        #endregion

        #region 获取领标单处理流程列表

        /// <summary>
        /// 获取领标单处理流程列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static List<CollarLableDocumentProcess> GetCollarLableDocumentProcessList(IQuery query)
        {
            var collarLableDocumentProcessList = collarLableDocumentProcessRepository.GetList(query);
            collarLableDocumentProcessList = LoadOtherObjectData(collarLableDocumentProcessList, query);
            return collarLableDocumentProcessList;
        }

        /// <summary>
        /// 获取领标单处理流程列表
        /// </summary>
        /// <param name="collarLableDocumentProcessSysNos">领标单处理流程编号</param>
        /// <returns></returns>
        public static List<CollarLableDocumentProcess> GetCollarLableDocumentProcessList(IEnumerable<Guid> collarLableDocumentProcessSysNos)
        {
            if (collarLableDocumentProcessSysNos.IsNullOrEmpty())
            {
                return new List<CollarLableDocumentProcess>(0);
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentProcessQuery>(c => collarLableDocumentProcessSysNos.Contains(c.SysNo));
            return GetCollarLableDocumentProcessList(query);
        }

        #endregion

        #region 获取领标单处理流程分页

        /// <summary>
        /// 获取领标单处理流程分页
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public static IPaging<CollarLableDocumentProcess> GetCollarLableDocumentProcessPaging(IQuery query)
        {
            var collarLableDocumentProcessPaging = collarLableDocumentProcessRepository.GetPaging(query);
            var collarLableDocumentProcessList = LoadOtherObjectData(collarLableDocumentProcessPaging, query);
            return new Paging<CollarLableDocumentProcess>(collarLableDocumentProcessPaging.Page, collarLableDocumentProcessPaging.PageSize, collarLableDocumentProcessPaging.TotalCount, collarLableDocumentProcessList);
        }

        #endregion

        #region 加载其它数据

        /// <summary>
        /// 加载其它数据
        /// </summary>
        /// <param name="collarLableDocumentProcesss">领标单处理流程数据</param>
        /// <param name="query">筛选条件</param>
        /// <returns></returns>
        static List<CollarLableDocumentProcess> LoadOtherObjectData(IEnumerable<CollarLableDocumentProcess> collarLableDocumentProcesss, IQuery query)
        {
            if (collarLableDocumentProcesss.IsNullOrEmpty())
            {
                return new List<CollarLableDocumentProcess>(0);
            }
            if (query == null)
            {
                return collarLableDocumentProcesss.ToList();
            }

            foreach (var collarLableDocumentProcess in collarLableDocumentProcesss)
            {
                if (collarLableDocumentProcess == null)
                {
                    continue;
                }
            }

            return collarLableDocumentProcesss.ToList();
        }

        #endregion

        #region 删除领标单处理流程

        /// <summary>
        /// 删除领标单处理流程
        /// </summary>
        /// <param name="deleteCollarLableDocumentProcess">删除信息</param>
        /// <returns>执行结果</returns>
        public static Result DeleteCollarLableDocumentProcess(DeleteCollarLableDocumentProcess deleteCollarLableDocumentProcess)
        {
            var collarLableDocumentProcesss = GetCollarLableDocumentProcessList(deleteCollarLableDocumentProcess.SysNos);
            collarLableDocumentProcesss.ForEach(c => c.Remove());
            return Result.SuccessResult("删除成功");
        }

        #endregion
    }
}
