using System;
using System.Collections.Generic;
using MicBeach.Develop.Domain.Aggregation;
using MicBeach.Util;
using MicBeach.Util.Extension;
using MicBeach.Util.Code;
using MicBeach.Util.Data;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Response;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Domain.Bcl.Service;
using System.Threading.Tasks;

namespace WMSForm.Domain.Bcl.Model
{
	/// <summary>
	/// 领标单
	/// </summary>
	public class CollarLableDocument:AggregationRoot<CollarLableDocument>
	{
		ICollarLableDocumentRepository collarLableDocumentRepository = null;

		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		protected Guid _sysNo;
		
		/// <summary>
		/// 单据编号
		/// </summary>
		protected string _billNo;
		
		/// <summary>
		/// 单据标题
		/// </summary>
		protected string _billTitle;
		
		/// <summary>
		/// 领标单类型
		/// </summary>
		protected int _billType;
		
		/// <summary>
		/// 提交账号
		/// </summary>
		protected Guid _userSysNo;
		
		/// <summary>
		/// 提交用户名
		/// </summary>
		protected string _userName;
		
		/// <summary>
		/// 企业名称
		/// </summary>
		protected string _enterpriseName;
		
		/// <summary>
		/// 企业代码
		/// </summary>
		protected string _enterpriseCode;
		
		/// <summary>
		/// 所属部门
		/// </summary>
		protected Guid _departmentSysNo;
		
		/// <summary>
		/// 部门名称
		/// </summary>
		protected string _departmentName;
		
		/// <summary>
		/// 发票类型
		/// </summary>
		protected int _invoiceType;
		
		/// <summary>
		/// 单据备注
		/// </summary>
		protected string _remark;
		
		/// <summary>
		/// 单据状态
		/// </summary>
		protected int _billStatus;
		
		/// <summary>
		/// 最近更新时间
		/// </summary>
		protected DateTime _lastUpdateDate;
		
		/// <summary>
		/// 提交时间
		/// </summary>
		protected DateTime _submitDate;
		
		/// <summary>
		/// 辅料费总计
		/// </summary>
		protected decimal _totalAdjuvantAmount;
		
		/// <summary>
		/// 服务费总计
		/// </summary>
		protected decimal _totalServiceAmount;
		
		/// <summary>
		/// 支付辅料费
		/// </summary>
		protected decimal _paidAdjuvantAmount;
		
		/// <summary>
		/// 支付服务费
		/// </summary>
		protected decimal _paidServiceAmount;
		
		/// <summary>
		/// 已付金额
		/// </summary>
		protected decimal _paidAmount;
		
		/// <summary>
		/// 物流公司
		/// </summary>
		protected string _logisticsName;
		
		/// <summary>
		/// 物流编号
		/// </summary>
		protected string _logisticsNo;
		
		/// <summary>
		/// 品牌
		/// </summary>
		protected Guid _brandSysNo;
		
		/// <summary>
		/// 品牌名
		/// </summary>
		protected string _brandName;
		
		/// <summary>
		/// 品牌企业名
		/// </summary>
		protected string _brandEnterpriseName;
		
		/// <summary>
		/// 单据信息说明
		/// </summary>
		protected string _billDescRemark;
		
		/// <summary>
		/// 是否生成了领标码
		/// </summary>
		protected bool _isGenerateLableCode;
		
		/// <summary>
		/// 所属店铺
		/// </summary>
		protected Guid _storeSysNo;
		
		/// <summary>
		/// 店铺名
		/// </summary>
		protected string _storeName;
		
		/// <summary>
		/// 应用了年度服务费
		/// </summary>
		protected bool _applyYearService;
		
		/// <summary>
		/// 版本号
		/// </summary>
		protected long _versionNo;
		
		#endregion

		#region 构造方法

		/// <summary>
		/// 实例化领标单对象
		/// </summary>
		/// <param name="sysNo">编号</param>
        internal CollarLableDocument()
        {
            collarLableDocumentRepository=this.Instance<ICollarLableDocumentRepository>();
					}

		#endregion

		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get
			{
				return _sysNo;
			}
			protected set
			{
				_sysNo=value;
			}
		}
		
		/// <summary>
		/// 单据编号
		/// </summary>
		public string BillNo
		{
			get
			{
				return _billNo;
			}
			protected set
			{
				_billNo=value;
			}
		}
		
		/// <summary>
		/// 单据标题
		/// </summary>
		public string BillTitle
		{
			get
			{
				return _billTitle;
			}
			protected set
			{
				_billTitle=value;
			}
		}
		
		/// <summary>
		/// 领标单类型
		/// </summary>
		public int BillType
		{
			get
			{
				return _billType;
			}
			protected set
			{
				_billType=value;
			}
		}
		
		/// <summary>
		/// 提交账号
		/// </summary>
		public Guid UserSysNo
		{
			get
			{
				return _userSysNo;
			}
			protected set
			{
				_userSysNo=value;
			}
		}
		
		/// <summary>
		/// 提交用户名
		/// </summary>
		public string UserName
		{
			get
			{
				return _userName;
			}
			protected set
			{
				_userName=value;
			}
		}
		
		/// <summary>
		/// 企业名称
		/// </summary>
		public string EnterpriseName
		{
			get
			{
				return _enterpriseName;
			}
			protected set
			{
				_enterpriseName=value;
			}
		}
		
		/// <summary>
		/// 企业代码
		/// </summary>
		public string EnterpriseCode
		{
			get
			{
				return _enterpriseCode;
			}
			protected set
			{
				_enterpriseCode=value;
			}
		}
		
		/// <summary>
		/// 所属部门
		/// </summary>
		public Guid DepartmentSysNo
		{
			get
			{
				return _departmentSysNo;
			}
			protected set
			{
				_departmentSysNo=value;
			}
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName
		{
			get
			{
				return _departmentName;
			}
			protected set
			{
				_departmentName=value;
			}
		}
		
		/// <summary>
		/// 发票类型
		/// </summary>
		public int InvoiceType
		{
			get
			{
				return _invoiceType;
			}
			protected set
			{
				_invoiceType=value;
			}
		}
		
		/// <summary>
		/// 单据备注
		/// </summary>
		public string Remark
		{
			get
			{
				return _remark;
			}
			protected set
			{
				_remark=value;
			}
		}
		
		/// <summary>
		/// 单据状态
		/// </summary>
		public int BillStatus
		{
			get
			{
				return _billStatus;
			}
			protected set
			{
				_billStatus=value;
			}
		}
		
		/// <summary>
		/// 最近更新时间
		/// </summary>
		public DateTime LastUpdateDate
		{
			get
			{
				return _lastUpdateDate;
			}
			set
			{
				_lastUpdateDate=value;
			}
		}
		
		/// <summary>
		/// 提交时间
		/// </summary>
		public DateTime SubmitDate
		{
			get
			{
				return _submitDate;
			}
			protected set
			{
				_submitDate=value;
			}
		}
		
		/// <summary>
		/// 辅料费总计
		/// </summary>
		public decimal TotalAdjuvantAmount
		{
			get
			{
				return _totalAdjuvantAmount;
			}
			protected set
			{
				_totalAdjuvantAmount=value;
			}
		}
		
		/// <summary>
		/// 服务费总计
		/// </summary>
		public decimal TotalServiceAmount
		{
			get
			{
				return _totalServiceAmount;
			}
			protected set
			{
				_totalServiceAmount=value;
			}
		}
		
		/// <summary>
		/// 支付辅料费
		/// </summary>
		public decimal PaidAdjuvantAmount
		{
			get
			{
				return _paidAdjuvantAmount;
			}
			protected set
			{
				_paidAdjuvantAmount=value;
			}
		}
		
		/// <summary>
		/// 支付服务费
		/// </summary>
		public decimal PaidServiceAmount
		{
			get
			{
				return _paidServiceAmount;
			}
			protected set
			{
				_paidServiceAmount=value;
			}
		}
		
		/// <summary>
		/// 已付金额
		/// </summary>
		public decimal PaidAmount
		{
			get
			{
				return _paidAmount;
			}
			protected set
			{
				_paidAmount=value;
			}
		}
		
		/// <summary>
		/// 物流公司
		/// </summary>
		public string LogisticsName
		{
			get
			{
				return _logisticsName;
			}
			protected set
			{
				_logisticsName=value;
			}
		}
		
		/// <summary>
		/// 物流编号
		/// </summary>
		public string LogisticsNo
		{
			get
			{
				return _logisticsNo;
			}
			protected set
			{
				_logisticsNo=value;
			}
		}
		
		/// <summary>
		/// 品牌
		/// </summary>
		public Guid BrandSysNo
		{
			get
			{
				return _brandSysNo;
			}
			protected set
			{
				_brandSysNo=value;
			}
		}
		
		/// <summary>
		/// 品牌名
		/// </summary>
		public string BrandName
		{
			get
			{
				return _brandName;
			}
			protected set
			{
				_brandName=value;
			}
		}
		
		/// <summary>
		/// 品牌企业名
		/// </summary>
		public string BrandEnterpriseName
		{
			get
			{
				return _brandEnterpriseName;
			}
			protected set
			{
				_brandEnterpriseName=value;
			}
		}
		
		/// <summary>
		/// 单据信息说明
		/// </summary>
		public string BillDescRemark
		{
			get
			{
				return _billDescRemark;
			}
			protected set
			{
				_billDescRemark=value;
			}
		}
		
		/// <summary>
		/// 是否生成了领标码
		/// </summary>
		public bool IsGenerateLableCode
		{
			get
			{
				return _isGenerateLableCode;
			}
			protected set
			{
				_isGenerateLableCode=value;
			}
		}
		
		/// <summary>
		/// 所属店铺
		/// </summary>
		public Guid StoreSysNo
		{
			get
			{
				return _storeSysNo;
			}
			protected set
			{
				_storeSysNo=value;
			}
		}
		
		/// <summary>
		/// 店铺名
		/// </summary>
		public string StoreName
		{
			get
			{
				return _storeName;
			}
			protected set
			{
				_storeName=value;
			}
		}
		
		/// <summary>
		/// 应用了年度服务费
		/// </summary>
		public bool ApplyYearService
		{
			get
			{
				return _applyYearService;
			}
			protected set
			{
				_applyYearService=value;
			}
		}
		
		/// <summary>
		/// 版本号
		/// </summary>
		public long VersionNo
		{
			get
			{
				return _versionNo;
			}
			protected set
			{
				_versionNo=value;
			}
		}
		
		#endregion

		#region 方法

		#region 功能方法

		#region 保存

		/// <summary>
		/// 保存
		/// </summary>
		public override async Task SaveAsync()
		{
            await collarLableDocumentRepository.SaveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region	移除

		/// <summary>
		/// 移除
		/// </summary>
		public override async Task RemoveAsync()
		{
            await collarLableDocumentRepository.RemoveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region 初始化标识信息

		/// <summary>
		/// 初始化标识信息
		/// </summary>
		public override void InitPrimaryValue()
		{
            base.InitPrimaryValue();
                        _sysNo = GenerateCollarLableDocumentSysNo();
            		}

        #endregion

        #region 判断标识对象值是否为空

        /// <summary>
        /// 判断标识对象值是否为空
        /// </summary>
        /// <returns></returns>
        public override bool PrimaryValueIsNone()
        {
            return _sysNo.IsEmpty();
        }

        #endregion

        #region 判断领标单相等

        /// <summary>
        /// 判断领标单对象是否相等
        /// </summary>
        /// <param name="obj">另一个领标单对象</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is CollarLableDocument))
            {
                return false;
            }
            var otherCollarLableDocument = obj as CollarLableDocument;
            return _sysNo == otherCollarLableDocument.SysNo;
        }

        /// <summary>
        /// get hash code
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return 0;
        }

        #endregion


        #endregion

        #region 内部方法


        #endregion

        #region 静态方法

        #region 生成一个领标单编号

        /// <summary>
        /// 生成一个领标单编号
        /// </summary>
        /// <returns></returns>
        public static Guid GenerateCollarLableDocumentSysNo()
        {
            return Guid.NewGuid();
        }

        #endregion

        #region 创建领标单

        /// <summary>
        /// 创建一个领标单对象
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocument CreateCollarLableDocument(Guid sysNo)
        {
            sysNo = sysNo.IsEmpty() ? GenerateCollarLableDocumentSysNo() : sysNo;
            return new CollarLableDocument()
            {
                SysNo=sysNo
            };
        }

        #endregion

        #endregion

        #endregion
	}
}