using System;
using System.Collections.Generic;
using System.Text;

namespace WMSForm.Domain.Bcl.Service.Request
{
    /// <summary>
    /// 删除领标单
    /// </summary>
    public class DeleteCollarLableDocument
    {
        /// <summary>
        /// 领标单编号
        /// </summary>
        public List<Guid> SysNos
        {
            get;set;
        }
    }
}
