using System;
using System.Collections.Generic;
using MicBeach.Develop.Domain.Aggregation;
using MicBeach.Util;
using MicBeach.Util.Extension;
using MicBeach.Util.Code;
using MicBeach.Util.Data;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Response;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.Domain.Bcl.Service;
using System.Threading.Tasks;

namespace WMSForm.Domain.Bcl.Model
{
	/// <summary>
	/// 领标单处理流程
	/// </summary>
	public class CollarLableDocumentProcess:AggregationRoot<CollarLableDocumentProcess>
	{
		ICollarLableDocumentProcessRepository collarLableDocumentProcessRepository = null;

		#region	字段
		
		/// <summary>
		/// 主键编号
		/// </summary>
		protected Guid _sysNo;
		
		/// <summary>
		/// 领标单号
		/// </summary>
		protected Guid _lableDocumentSysNo;
		
		/// <summary>
		/// 审核部门
		/// </summary>
		protected Guid _departmentSysNo;
		
		/// <summary>
		/// 部门名称
		/// </summary>
		protected string _departmentName;
		
		/// <summary>
		/// 审核用户编号
		/// </summary>
		protected Guid _auditUserSysNo;
		
		/// <summary>
		/// 审核用户名称
		/// </summary>
		protected string _auditUserName;
		
		/// <summary>
		/// 审核顺序
		/// </summary>
		protected int _sortIndex;
		
		/// <summary>
		/// 首先审核
		/// </summary>
		protected bool _firstAudit;
		
		/// <summary>
		/// 最后审核
		/// </summary>
		protected bool _lastAudit;
		
		/// <summary>
		/// 审核状态
		/// </summary>
		protected int _auditStatus;
		
		/// <summary>
		/// 审核时间
		/// </summary>
		protected DateTime _auditDate;
		
		/// <summary>
		/// 审核备注
		/// </summary>
		protected string _auditRemark;
		
		#endregion

		#region 构造方法

		/// <summary>
		/// 实例化领标单处理流程对象
		/// </summary>
		/// <param name="sysNo">编号</param>
        internal CollarLableDocumentProcess()
        {
            collarLableDocumentProcessRepository=this.Instance<ICollarLableDocumentProcessRepository>();
					}

		#endregion

		#region	属性
		
		/// <summary>
		/// 主键编号
		/// </summary>
		public Guid SysNo
		{
			get
			{
				return _sysNo;
			}
			protected set
			{
				_sysNo=value;
			}
		}
		
		/// <summary>
		/// 领标单号
		/// </summary>
		public Guid LableDocumentSysNo
		{
			get
			{
				return _lableDocumentSysNo;
			}
			protected set
			{
				_lableDocumentSysNo=value;
			}
		}
		
		/// <summary>
		/// 审核部门
		/// </summary>
		public Guid DepartmentSysNo
		{
			get
			{
				return _departmentSysNo;
			}
			protected set
			{
				_departmentSysNo=value;
			}
		}
		
		/// <summary>
		/// 部门名称
		/// </summary>
		public string DepartmentName
		{
			get
			{
				return _departmentName;
			}
			protected set
			{
				_departmentName=value;
			}
		}
		
		/// <summary>
		/// 审核用户编号
		/// </summary>
		public Guid AuditUserSysNo
		{
			get
			{
				return _auditUserSysNo;
			}
			protected set
			{
				_auditUserSysNo=value;
			}
		}
		
		/// <summary>
		/// 审核用户名称
		/// </summary>
		public string AuditUserName
		{
			get
			{
				return _auditUserName;
			}
			protected set
			{
				_auditUserName=value;
			}
		}
		
		/// <summary>
		/// 审核顺序
		/// </summary>
		public int SortIndex
		{
			get
			{
				return _sortIndex;
			}
			protected set
			{
				_sortIndex=value;
			}
		}
		
		/// <summary>
		/// 首先审核
		/// </summary>
		public bool FirstAudit
		{
			get
			{
				return _firstAudit;
			}
			protected set
			{
				_firstAudit=value;
			}
		}
		
		/// <summary>
		/// 最后审核
		/// </summary>
		public bool LastAudit
		{
			get
			{
				return _lastAudit;
			}
			protected set
			{
				_lastAudit=value;
			}
		}
		
		/// <summary>
		/// 审核状态
		/// </summary>
		public int AuditStatus
		{
			get
			{
				return _auditStatus;
			}
			protected set
			{
				_auditStatus=value;
			}
		}
		
		/// <summary>
		/// 审核时间
		/// </summary>
		public DateTime AuditDate
		{
			get
			{
				return _auditDate;
			}
			set
			{
				_auditDate=value;
			}
		}
		
		/// <summary>
		/// 审核备注
		/// </summary>
		public string AuditRemark
		{
			get
			{
				return _auditRemark;
			}
			protected set
			{
				_auditRemark=value;
			}
		}
		
		#endregion

		#region 方法

		#region 功能方法

		#region 保存

		/// <summary>
		/// 保存
		/// </summary>
		public override async Task SaveAsync()
		{
            await collarLableDocumentProcessRepository.SaveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region	移除

		/// <summary>
		/// 移除
		/// </summary>
		public override async Task RemoveAsync()
		{
            await collarLableDocumentProcessRepository.RemoveAsync(this).ConfigureAwait(false);
		}

		#endregion

		#region 初始化标识信息

		/// <summary>
		/// 初始化标识信息
		/// </summary>
		public override void InitPrimaryValue()
		{
            base.InitPrimaryValue();
                        _sysNo = GenerateCollarLableDocumentProcessSysNo();
            		}

        #endregion

        #region 判断标识对象值是否为空

        /// <summary>
        /// 判断标识对象值是否为空
        /// </summary>
        /// <returns></returns>
        public override bool PrimaryValueIsNone()
        {
            return _sysNo.IsEmpty();
        }

        #endregion

        #region 判断领标单处理流程相等

        /// <summary>
        /// 判断领标单处理流程对象是否相等
        /// </summary>
        /// <param name="obj">另一个领标单处理流程对象</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is CollarLableDocumentProcess))
            {
                return false;
            }
            var otherCollarLableDocumentProcess = obj as CollarLableDocumentProcess;
            return _sysNo == otherCollarLableDocumentProcess.SysNo;
        }

        /// <summary>
        /// get hash code
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return 0;
        }

        #endregion


        #endregion

        #region 内部方法


        #endregion

        #region 静态方法

        #region 生成一个领标单处理流程编号

        /// <summary>
        /// 生成一个领标单处理流程编号
        /// </summary>
        /// <returns></returns>
        public static Guid GenerateCollarLableDocumentProcessSysNo()
        {
            return Guid.NewGuid();
        }

        #endregion

        #region 创建领标单处理流程

        /// <summary>
        /// 创建一个领标单处理流程对象
        /// </summary>
        /// <param name="sysNo">编号</param>
        /// <returns></returns>
        public static CollarLableDocumentProcess CreateCollarLableDocumentProcess(Guid sysNo)
        {
            sysNo = sysNo.IsEmpty() ? GenerateCollarLableDocumentProcessSysNo() : sysNo;
            return new CollarLableDocumentProcess()
            {
                SysNo=sysNo
            };
        }

        #endregion

        #endregion

        #endregion
	}
}