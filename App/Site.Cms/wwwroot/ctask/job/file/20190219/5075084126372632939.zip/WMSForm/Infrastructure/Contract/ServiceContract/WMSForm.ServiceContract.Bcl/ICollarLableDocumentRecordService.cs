using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;

namespace WMSForm.ServiceContract.Bcl
{
    /// <summary>
    /// 领表单处理记录服务接口
    /// </summary>
    public interface ICollarLableDocumentRecordService
    {
        #region 保存领表单处理记录

        /// <summary>
        /// 保存领表单处理记录
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        Result<CollarLableDocumentRecordDto> SaveCollarLableDocumentRecord(SaveCollarLableDocumentRecordCmdDto saveInfo);

        #endregion

        #region 获取领表单处理记录

        /// <summary>
        /// 获取领表单处理记录
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        CollarLableDocumentRecordDto GetCollarLableDocumentRecord(CollarLableDocumentRecordFilterDto filter);

        #endregion

        #region 获取领表单处理记录列表

        /// <summary>
        /// 获取领表单处理记录列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        List<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordList(CollarLableDocumentRecordFilterDto filter);

        #endregion

		#region 获取领表单处理记录分页

        /// <summary>
        /// 获取领表单处理记录分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IPaging<CollarLableDocumentRecordDto> GetCollarLableDocumentRecordPaging(CollarLableDocumentRecordFilterDto filter);

        #endregion

		#region 删除领表单处理记录

        /// <summary>
        /// 删除领表单处理记录
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        Result DeleteCollarLableDocumentRecord(DeleteCollarLableDocumentRecordCmdDto deleteInfo);

        #endregion
    }
}
