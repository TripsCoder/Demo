using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DTO.Bcl.Cmd
{
    /// <summary>
    /// 删除领标单处理流程
    /// </summary>
    public class DeleteCollarLableDocumentProcessCmdDto
    {
        /// <summary>
        /// 领标单处理流程编号
        /// </summary>
        public IEnumerable<Guid> CollarLableDocumentProcessIds
        {
            get;set;
        }
    }
}
