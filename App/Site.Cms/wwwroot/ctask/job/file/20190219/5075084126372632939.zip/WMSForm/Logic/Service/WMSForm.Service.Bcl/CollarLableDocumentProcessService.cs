using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Paging;
using MicBeach.Util.Response;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.ServiceContract.Bcl;
using WMSForm.BusinessContract.Bcl;

namespace WMSForm.Service.Bcl
{
    /// <summary>
    /// 领标单处理流程服务
    /// </summary>
    public class CollarLableDocumentProcessService : ICollarLableDocumentProcessService
    {
	    ICollarLableDocumentProcessBusiness collarLableDocumentProcessBusiness = null;

		public CollarLableDocumentProcessService(ICollarLableDocumentProcessBusiness collarLableDocumentProcessBusiness)
        {
            this.collarLableDocumentProcessBusiness = collarLableDocumentProcessBusiness;
        }

		#region 保存领标单处理流程

        /// <summary>
        /// 保存领标单处理流程
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentProcessDto> SaveCollarLableDocumentProcess(SaveCollarLableDocumentProcessCmdDto saveInfo)
		{
            return collarLableDocumentProcessBusiness.SaveCollarLableDocumentProcess(saveInfo);
		}

        #endregion

        #region 获取领标单处理流程

        /// <summary>
        /// 获取领标单处理流程
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentProcessDto GetCollarLableDocumentProcess(CollarLableDocumentProcessFilterDto filter)
		{
            return collarLableDocumentProcessBusiness.GetCollarLableDocumentProcess(filter);
		}

        #endregion

        #region 获取领标单处理流程列表

        /// <summary>
        /// 获取领标单处理流程列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessList(CollarLableDocumentProcessFilterDto filter)
		{
			return collarLableDocumentProcessBusiness.GetCollarLableDocumentProcessList(filter); 
		}

        #endregion

		#region 获取领标单处理流程分页

        /// <summary>
        /// 获取领标单处理流程分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessPaging(CollarLableDocumentProcessFilterDto filter)
		{
			return collarLableDocumentProcessBusiness.GetCollarLableDocumentProcessPaging(filter); 
		}

        #endregion

		#region 删除领标单处理流程

        /// <summary>
        /// 删除领标单处理流程
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocumentProcess(DeleteCollarLableDocumentProcessCmdDto deleteInfo)
        {
            return collarLableDocumentProcessBusiness.DeleteCollarLableDocumentProcess(deleteInfo);
        }

        #endregion
    }
}
