using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMSForm.DTO.Bcl.Cmd
{
    /// <summary>
    /// 保存领标单处理流程信息
    /// </summary>
    public class SaveCollarLableDocumentProcessCmdDto
    {
        /// <summary>
        /// 领标单处理流程信息
        /// </summary>
        public CollarLableDocumentProcessCmdDto CollarLableDocumentProcess
        {
            get;set;
        }
    }
}
