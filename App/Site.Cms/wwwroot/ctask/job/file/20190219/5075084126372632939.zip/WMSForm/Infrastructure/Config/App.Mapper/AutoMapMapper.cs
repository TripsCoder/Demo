using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper.Configuration;
using MicBeach.Util.Data;
using MicBeach.Util.Extension;
using MicBeach.Util.ObjectMap;
using WMSForm.Domain.Bcl.Model;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.Entity.Bcl;
using WMSForm.ViewModel.Bcl.Request;
using WMSForm.ViewModel.Bcl.Response;

namespace App.Mapper
{
    public class AutoMapMapper : IObjectMap
    {
        /// <summary>
        /// 转换对象
        /// </summary>
        /// <typeparam name="T">目标类型</typeparam>
        /// <param name="sourceObj">源对象类型</param>
        /// <returns>目标对象类型</returns>
        public T MapTo<T>(object sourceObj)
        {
            return AutoMapper.Mapper.Map<T>(sourceObj);
        }

        /// <summary>
        /// /// <summary>
        /// 注册对象映射
        /// </summary>
        /// </summary>
        public void Register()
        {
            var cfg = new MapperConfigurationExpression();
            cfg.ShouldMapProperty = p => p.GetMethod.IsPublic || p.GetMethod.IsAssembly || p.GetMethod.IsPrivate || p.GetMethod.IsFamilyAndAssembly || p.GetMethod.IsFamily || p.GetMethod.IsFamilyOrAssembly;

            cfg.CreateMap<CollarLableDocument, CollarLableDocumentEntity>();
            cfg.CreateMap<CollarLableDocumentEntity, CollarLableDocument>();
            cfg.CreateMap<CollarLableDocument, CollarLableDocumentDto>();
            cfg.CreateMap<CollarLableDocumentCmdDto, CollarLableDocument>();
            cfg.CreateMap<CollarLableDocumentDto, CollarLableDocumentViewModel>();
            cfg.CreateMap<CollarLableDocumentDto, EditCollarLableDocumentViewModel>();
            cfg.CreateMap<EditCollarLableDocumentViewModel, CollarLableDocumentCmdDto>();

            #region CollarLableDocumentProcess

            cfg.CreateMap<CollarLableDocumentProcess, CollarLableDocumentProcessEntity>();
            cfg.CreateMap<CollarLableDocumentProcessEntity, CollarLableDocumentProcess>();
            cfg.CreateMap<CollarLableDocumentProcess, CollarLableDocumentProcessDto>();
            cfg.CreateMap<CollarLableDocumentProcessCmdDto, CollarLableDocumentProcess>();
            cfg.CreateMap<CollarLableDocumentProcessDto, CollarLableDocumentProcessViewModel>();
            cfg.CreateMap<CollarLableDocumentProcessDto, EditCollarLableDocumentProcessViewModel>();
            cfg.CreateMap<EditCollarLableDocumentProcessViewModel, CollarLableDocumentProcessCmdDto>();

            #endregion

            #region CollarLableDocumentRecord

            cfg.CreateMap<CollarLableDocumentRecord, CollarLableDocumentRecordEntity>();
            cfg.CreateMap<CollarLableDocumentRecordEntity, CollarLableDocumentRecord>();
            cfg.CreateMap<CollarLableDocumentRecord, CollarLableDocumentRecordDto>();
            cfg.CreateMap<CollarLableDocumentRecordCmdDto, CollarLableDocumentRecord>();
            cfg.CreateMap<CollarLableDocumentRecordDto, CollarLableDocumentRecordViewModel>();
            cfg.CreateMap<CollarLableDocumentRecordDto, EditCollarLableDocumentRecordViewModel>();
            cfg.CreateMap<EditCollarLableDocumentRecordViewModel, CollarLableDocumentRecordCmdDto>();

            #endregion


            AutoMapper.Mapper.Initialize(cfg);
        }
    }
}
