using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicBeach.Util.Extension;
using MicBeach.Util;
using MicBeach.Develop.UnitOfWork;
using MicBeach.Util.Response;
using MicBeach.Develop.CQuery;
using MicBeach.Util.Paging;
using WMSForm.Domain.Bcl.Model;
using WMSForm.Domain.Bcl.Service;
using WMSForm.DTO.Bcl.Cmd;
using WMSForm.DTO.Bcl.Query;
using WMSForm.DTO.Bcl.Query.Filter;
using WMSForm.Query.Bcl;
using WMSForm.Domain.Bcl.Repository;
using WMSForm.BusinessContract.Bcl;
using WMSForm.Domain.Bcl.Service.Request;

namespace WMSForm.Business.Bcl
{
    /// <summary>
    /// 领标单处理流程业务
    /// </summary>
    public class CollarLableDocumentProcessBusiness:ICollarLableDocumentProcessBusiness
    {
        public CollarLableDocumentProcessBusiness()
        {
        }

        #region 保存领标单处理流程

        /// <summary>
        /// 保存领标单处理流程
        /// </summary>
        /// <param name="saveInfo">保存信息</param>
        /// <returns>执行结果</returns>
        public Result<CollarLableDocumentProcessDto> SaveCollarLableDocumentProcess(SaveCollarLableDocumentProcessCmdDto saveInfo)
		{
            if (saveInfo == null)
            {
                return Result<CollarLableDocumentProcessDto>.FailedResult("没有指定任何要保持的信息");
            }
            using (var businessWork = UnitOfWork.Create())
            {
                var saveResult = CollarLableDocumentProcessService.SaveCollarLableDocumentProcess(saveInfo.CollarLableDocumentProcess.MapTo<CollarLableDocumentProcess>());
                if (!saveResult.Success)
                {
                    return Result<CollarLableDocumentProcessDto>.FailedResult(saveResult.Message);
                }
                var commitResult = businessWork.Commit();
                Result<CollarLableDocumentProcessDto> result = null;
                if (commitResult.ExecutedSuccess)
                {
                    result = Result<CollarLableDocumentProcessDto>.SuccessResult("保存成功");
                    result.Data = saveResult.Data.MapTo<CollarLableDocumentProcessDto>();
                }
                else
                {
                    result = Result<CollarLableDocumentProcessDto>.FailedResult("保存失败");
                }
                return result;
            }
		}

        #endregion

        #region 获取领标单处理流程

        /// <summary>
        /// 获取领标单处理流程
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public CollarLableDocumentProcessDto GetCollarLableDocumentProcess(CollarLableDocumentProcessFilterDto filter)
		{
            var collarLableDocumentProcess = CollarLableDocumentProcessService.GetCollarLableDocumentProcess(CreateQueryObject(filter));
            return collarLableDocumentProcess.MapTo<CollarLableDocumentProcessDto>();
		}

        #endregion

        #region 获取领标单处理流程列表

        /// <summary>
        /// 获取领标单处理流程列表
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public List<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessList(CollarLableDocumentProcessFilterDto filter)
		{
			var collarLableDocumentProcessList = CollarLableDocumentProcessService.GetCollarLableDocumentProcessList(CreateQueryObject(filter));
            return collarLableDocumentProcessList.Select(c => c.MapTo<CollarLableDocumentProcessDto>()).ToList();
		}

        #endregion

		#region 获取领标单处理流程分页

        /// <summary>
        /// 获取领标单处理流程分页
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        public IPaging<CollarLableDocumentProcessDto> GetCollarLableDocumentProcessPaging(CollarLableDocumentProcessFilterDto filter)
		{
		    var collarLableDocumentProcessPaging = CollarLableDocumentProcessService.GetCollarLableDocumentProcessPaging(CreateQueryObject(filter));
            return collarLableDocumentProcessPaging.ConvertTo<CollarLableDocumentProcessDto>();
		}

        #endregion

		#region 删除领标单处理流程

        /// <summary>
        /// 删除领标单处理流程
        /// </summary>
        /// <param name="deleteInfo">删除信息</param>
        /// <returns>执行结果</returns>
        public Result DeleteCollarLableDocumentProcess(DeleteCollarLableDocumentProcessCmdDto deleteInfo)
        {
            #region 参数判断

            if (deleteInfo == null || deleteInfo.CollarLableDocumentProcessIds.IsNullOrEmpty())
            {
                return Result.FailedResult("没有指定要删除的领标单处理流程");
            }

            #endregion

            using (var businessWork = UnitOfWork.Create())
            {
                var deleteResult = CollarLableDocumentProcessService.DeleteCollarLableDocumentProcess(deleteInfo.MapTo<DeleteCollarLableDocumentProcess>());
                if (!deleteResult.Success)
                {
                    return deleteResult;
                }
                var commitResult = businessWork.Commit();
                return commitResult.ExecutedSuccess ? Result.SuccessResult("删除成功") : Result.FailedResult("删除失败");
            }
        }

        #endregion

		#region 根据查询条件生成查询对象

        /// <summary>
        /// 根据查询条件生成查询对象
        /// </summary>
        /// <param name="filter">查询条件</param>
        /// <returns></returns>
        IQuery CreateQueryObject(CollarLableDocumentProcessFilterDto filter)
        {
            if (filter == null)
            {
                return null;
            }
            IQuery query = QueryFactory.Create<CollarLableDocumentProcessQuery>(filter);

			#region 数据筛选

							if(!filter.SysNos.IsNullOrEmpty())
			{
				query.In<CollarLableDocumentProcessQuery>(c => c.SysNo, filter.SysNos);
			}
            if (!filter.ExcludeSysNos.IsNullOrEmpty())
            {
                query.NotIn<CollarLableDocumentProcessQuery>(c => c.SysNo, filter.ExcludeSysNos);
            }
							            if(!filter.LableDocumentSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.LableDocumentSysNo, filter.LableDocumentSysNo);
			}
            				            if(!filter.DepartmentSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.DepartmentSysNo, filter.DepartmentSysNo);
			}
            							if(!filter.DepartmentName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.DepartmentName, filter.DepartmentName);
			}
							            if(!filter.AuditUserSysNo.IsEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.AuditUserSysNo, filter.AuditUserSysNo);
			}
            							if(!filter.AuditUserName.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.AuditUserName, filter.AuditUserName);
			}
										if(filter.SortIndex.HasValue)
			{
            query.Equal<CollarLableDocumentProcessQuery>(c => c.SortIndex, filter.SortIndex.Value);
			}
										if(filter.FirstAudit.HasValue)
			{
            query.Equal<CollarLableDocumentProcessQuery>(c => c.FirstAudit, filter.FirstAudit.Value);
			}
										if(filter.LastAudit.HasValue)
			{
            query.Equal<CollarLableDocumentProcessQuery>(c => c.LastAudit, filter.LastAudit.Value);
			}
										if(filter.AuditStatus.HasValue)
			{
            query.Equal<CollarLableDocumentProcessQuery>(c => c.AuditStatus, filter.AuditStatus.Value);
			}
										if(filter.AuditDate.HasValue)
			{
            query.Equal<CollarLableDocumentProcessQuery>(c => c.AuditDate, filter.AuditDate.Value);
			}
										if(!filter.AuditRemark.IsNullOrEmpty())
			{
			query.Equal<CollarLableDocumentProcessQuery>(c => c.AuditRemark, filter.AuditRemark);
			}
					
			#endregion

            #region 数据加载


            #endregion

            return query;
        }

        #endregion
    }
}
